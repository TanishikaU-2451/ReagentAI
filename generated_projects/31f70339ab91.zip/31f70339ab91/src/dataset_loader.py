import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, List
import logging
import os

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatasetLoader(nn.Module):
    def __init__(self, config: Dict):
        super(DatasetLoader, self).__init__()
        self.datasets = config['datasets']
        self.model = Model(config)

    def __getitem__(self, idx: int) -> torch.Tensor:
        dataset = self.datasets[idx]
        data, target = dataset['data'], dataset['target']
        data = data.to('cuda' if torch.cuda.is_available() else 'cpu')
        target = torch.tensor(target, dtype=torch.float32)
        return self.model(data), target

    def __len__(self):
        return len(self.datasets)

class DataModule(nn.Module):
    def __init__(self, config: Dict):
        super(DataModule, self).__init__()
        self.datasets = config['datasets']
        self.model = Model(config)

    def __getitem__(self, idx: int) -> torch.Tensor:
        dataset = self.datasets[idx]
        data, target = dataset['data'], dataset['target']
        data = data.to('cuda' if torch.cuda.is_available() else 'cpu')
        target = torch.tensor(target, dtype=torch.float32)
        return self.model(data), target

    def __len__(self):
        return len(self.datasets)

class Trainer:
    def __init__(self, model: nn.Module, optimizer: optim.Optimizer, config: Dict):
        self.model = model
        self.optimizer = optimizer
        self.config = config

    def train(self, train_dataset: DatasetLoader, val_dataset: DatasetLoader, epochs: int):
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=self.config['batch_size'], shuffle=True)
        val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=self.config['batch_size'], shuffle=False)

        for epoch in range(epochs):
            self.model.train()
            total_loss = 0
            for batch in train_loader:
                input_data, target = batch
                input_data, target = input_data.to('cuda' if torch.cuda.is_available() else 'cpu'), target.to('cuda' if torch.cuda.is_available() else 'cpu')
                self.optimizer.zero_grad()
                output = self.model(input_data)
                loss = self.calculate_loss(output, target)
                loss.backward()
                self.optimizer.step()
                total_loss += loss.item()
            print(f'Epoch {epoch+1}, Loss: {total_loss / len(train_loader)}')

    def calculate_loss(self, output: torch.Tensor, target: torch.Tensor) -> float:
        return torch.mean((output - target) ** 2)

    def evaluate(self, test_dataset: DatasetLoader, val_loader: torch.utils.data.DataLoader):
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=self.config['batch_size'], shuffle=False)
        self.model.eval()
        total_loss = 0
        with torch.no_grad():
            for batch in test_loader:
                input_data, target = batch
                input_data, target = input_data.to('cuda' if torch.cuda.is_available() else 'cpu'), target.to('cuda' if torch.cuda.is_available() else 'cpu')
                output = self.model(input_data)
                loss = torch.mean((output - target) ** 2)
                total_loss += loss.item()
        print(f'Test Loss: {total_loss / len(test_loader)}')

# Example usage
if __name__ == '__main__':
    config = {
        'input_dim': 10,
        'hidden_dim': 20,
        'datasets': [
            {'data': torch.randn(100, 10), 'target': torch.randn(100, 1)},
            {'data': torch.randn(100, 10), 'target': torch.randn(100, 1)},
            {'data': torch.randn(100, 10), 'target': torch.randn(100, 1)},
        ],
    }
    model = Model(config)
    trainer = Trainer(model, optim.Adam(model.parameters(), lr=config['learning_rate']), config)
    trainer.train(DatasetLoader(config), DatasetLoader(config), 100)
    trainer.evaluate(DatasetLoader(config), DatasetLoader(config))