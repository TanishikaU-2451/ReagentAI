src/dataset_loader.py
```python
import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertModel
from typing import Dict, Any, List
from torch.utils.data import Dataset, DataLoader
from src.model import Model

class Dataset(Dataset):
    def __init__(self, data: List[Dict[str, Any]], tokenizer: BertTokenizer, config: Dict[str, Any]) -> None:
        self.data = data
        self.tokenizer = tokenizer
        self.config = config

    def __len__(self) -> int:
        return len(self.data)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        item = self.data[idx]
        input_ids = item['input_ids']
        attention_mask = item['attention_mask']
        labels = item['labels']

        # Preprocess input IDs
        input_ids = self.tokenizer.encode_plus(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_length=config['max_length'],
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )

        # Preprocess labels
        labels = self.tokenizer.encode_plus(
            labels=labels,
            max_length=config['max_length'],
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )

        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': labels
        }

class DatasetLoader:
    def __init__(self, data: List[Dict[str, Any]], tokenizer: BertTokenizer, config: Dict[str, Any]) -> None:
        self.data = data
        self.tokenizer = tokenizer
        self.config = config

    def get_dataloaders(self, split: str, batch_size: int) -> DataLoader:
        if split == 'train':
            return DataLoader(self.data, batch_size=batch_size, shuffle=True)
        elif split == 'val':
            return DataLoader(self.data, batch_size=batch_size, shuffle=False)
        elif split == 'test':
            return DataLoader(self.data, batch_size=batch_size, shuffle=False)
        else:
            raise ValueError('Invalid split')

    def get_train_dataloaders(self) -> DataLoader:
        return self.get_dataloaders(split='train', batch_size=self.config['batch_size'])

    def get_val_dataloaders(self) -> DataLoader:
        return self.get_dataloaders(split='val', batch_size=self.config['batch_size'])

    def get_test_dataloaders(self) -> DataLoader:
        return self.get_dataloaders(split='test', batch_size=self.config['batch_size'])