import pytest
import torch
from torch import nn
from torch.optim import optim
from transformers import BertTokenizer, BertModel
from typing import Dict, Any, List
from src.model import Model
from src.dataset_loader import Dataset, DatasetLoader
from conftest import get_tokenizer, get_config

def test_dataset_loader():
    # Test default config
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    dataloader = dataset_loader.get_dataloaders(split='train', batch_size=32)
    for i, (data, labels) in enumerate(dataloader):
        input_ids = data['input_ids']
        attention_mask = data['attention_mask']
        labels = data['labels']
        assert input_ids.shape == (len(data), tokenizer.max_length)
        assert attention_mask.shape == (len(data), tokenizer.max_length)
        assert labels.shape == (len(data), tokenizer.max_length)

    # Test edge cases
    empty_input = {'input_ids': [], 'attention_mask': [], 'labels': []}
    single_sample = {'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}
    batch_of_1 = [{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}]
    with pytest.raises(ValueError):
        dataset_loader.get_dataloaders(split='test', batch_size=32, data=empty_input)

    # Test shape checks
    def test_shape_check():
        input_ids = torch.randn(1, 10, 10)
        attention_mask = torch.randn(1, 10, 10)
        labels = torch.randn(1, 10, 10)
        dataset_loader = DatasetLoader(data=[input_ids, attention_mask, labels], tokenizer=get_tokenizer(), config=get_config())
        dataloader = dataset_loader.get_dataloaders(split='train', batch_size=32)
        for i, (data, labels) in enumerate(dataloader):
            input_ids = data['input_ids']
            attention_mask = data['attention_mask']
            labels = data['labels']
            assert input_ids.shape == (32, 10, 10)
            assert attention_mask.shape == (32, 10, 10)
            assert labels.shape == (32, 10, 10)

    test_shape_check()

def test_dataset():
    # Test default config
    config = get_config()
    tokenizer = get_tokenizer()
    dataset = Dataset(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    input_ids = dataset.data[0]['input_ids']
    attention_mask = dataset.data[0]['attention_mask']
    labels = dataset.data[0]['labels']
    assert input_ids.shape == (1, tokenizer.max_length)
    assert attention_mask.shape == (1, tokenizer.max_length)
    assert labels.shape == (1, tokenizer.max_length)

    # Test edge cases
    empty_input = {'input_ids': [], 'attention_mask': [], 'labels': []}
    single_sample = {'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}
    batch_of_1 = [{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}]
    with pytest.raises(ValueError):
        dataset.get_dataloaders(split='test', batch_size=32, data=empty_input)

    # Test shape checks
    def test_shape_check():
        input_ids = torch.randn(1, 10, 10)
        attention_mask = torch.randn(1, 10, 10)
        labels = torch.randn(1, 10, 10)
        dataset = Dataset(data=[input_ids, attention_mask, labels], tokenizer=get_tokenizer(), config=get_config())
        dataloader = dataset.get_dataloaders(split='train', batch_size=32)
        for i, (data, labels) in enumerate(dataloader):
            input_ids = data['input_ids']
            attention_mask = data['attention_mask']
            labels = data['labels']
            assert input_ids.shape == (32, 10, 10)
            assert attention_mask.shape == (32, 10, 10)
            assert labels.shape == (32, 10, 10)

    test_shape_check()

def test_model():
    # Test default config
    config = get_config()
    model = Model(config=config)
    input_ids = torch.randn(1, 10, 10)
    attention_mask = torch.randn(1, 10, 10)
    labels = torch.randn(1, 10, 10)
    output = model(input_ids, attention_mask, labels)
    assert output.shape == (1, 10, 10)

    # Test edge cases
    empty_input = {'input_ids': [], 'attention_mask': [], 'labels': []}
    single_sample = {'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}
    batch_of_1 = [{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}]
    with pytest.raises(ValueError):
        model(input_ids, attention_mask, labels)

    # Test forward pass
    input_ids = torch.randn(1, 10, 10)
    attention_mask = torch.randn(1, 10, 10)
    labels = torch.randn(1, 10, 10)
    output = model(input_ids, attention_mask, labels)
    assert output.shape == (1, 10, 10)

    # Test gradient flow
    input_ids = torch.randn(1, 10, 10)
    attention_mask = torch.randn(1, 10, 10)
    labels = torch.randn(1, 10, 10)
    output = model(input_ids, attention_mask, labels)
    loss = torch.randn(1, 10, 10)
    loss.backward()
    assert loss.grad.shape == (1, 10, 10)

def test_dataset_loader_default_config():
    # Test default config
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    dataloader = dataset_loader.get_dataloaders(split='train', batch_size=32)
    for i, (data, labels) in enumerate(dataloader):
        input_ids = data['input_ids']
        attention_mask = data['attention_mask']
        labels = data['labels']
        assert input_ids.shape == (32, tokenizer.max_length)
        assert attention_mask.shape == (32, tokenizer.max_length)
        assert labels.shape == (32, tokenizer.max_length)

def test_dataset_loader_invalid_split():
    # Test invalid split
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    with pytest.raises(ValueError):
        dataset_loader.get_dataloaders(split='test', batch_size=32)

def test_dataset_loader_get_train_dataloaders():
    # Test get_train_dataloaders
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    dataloader = dataset_loader.get_train_dataloaders()
    for i, (data, labels) in enumerate(dataloader):
        input_ids = data['input_ids']
        attention_mask = data['attention_mask']
        labels = data['labels']
        assert input_ids.shape == (32, tokenizer.max_length)
        assert attention_mask.shape == (32, tokenizer.max_length)
        assert labels.shape == (32, tokenizer.max_length)

def test_dataset_loader_get_val_dataloaders():
    # Test get_val_dataloaders
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    dataloader = dataset_loader.get_val_dataloaders()
    for i, (data, labels) in enumerate(dataloader):
        input_ids = data['input_ids']
        attention_mask = data['attention_mask']
        labels = data['labels']
        assert input_ids.shape == (32, tokenizer.max_length)
        assert attention_mask.shape == (32, tokenizer.max_length)
        assert labels.shape == (32, tokenizer.max_length)

def test_dataset_loader_get_test_dataloaders():
    # Test get_test_dataloaders
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    dataloader = dataset_loader.get_test_dataloaders()
    for i, (data, labels) in enumerate(dataloader):
        input_ids = data['input_ids']
        attention_mask = data['attention_mask']
        labels = data['labels']
        assert input_ids.shape == (32, tokenizer.max_length)
        assert attention_mask.shape == (32, tokenizer.max_length)
        assert labels.shape == (32, tokenizer.max_length)

def test_dataset_loader_get_dataloaders():
    # Test get_dataloaders
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    dataloader = dataset_loader.get_dataloaders(split='train', batch_size=32)
    for i, (data, labels) in enumerate(dataloader):
        input_ids = data['input_ids']
        attention_mask = data['attention_mask']
        labels = data['labels']
        assert input_ids.shape == (32, tokenizer.max_length)
        assert attention_mask.shape == (32, tokenizer.max_length)
        assert labels.shape == (32, tokenizer.max_length)

def test_dataset_loader_get_train_dataloaders_invalid_split():
    # Test get_train_dataloaders with invalid split
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    with pytest.raises(ValueError):
        dataset_loader.get_train_dataloaders(split='test', batch_size=32)

def test_dataset_loader_get_val_dataloaders_invalid_split():
    # Test get_val_dataloaders with invalid split
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    with pytest.raises(ValueError):
        dataset_loader.get_val_dataloaders(split='test', batch_size=32)

def test_dataset_loader_get_test_dataloaders_invalid_split():
    # Test get_test_dataloaders with invalid split
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    with pytest.raises(ValueError):
        dataset_loader.get_test_dataloaders(split='test', batch_size=32)

def test_dataset_loader_get_dataloaders_invalid_batch_size():
    # Test get_dataloaders with invalid batch size
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    with pytest.raises(ValueError):
        dataset_loader.get_dataloaders(split='train', batch_size=1)

def test_dataset_loader_get_train_dataloaders_invalid_batch_size():
    # Test get_train_dataloaders with invalid batch size
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data=[{'input_ids': [1, 2, 3], 'attention_mask': [0, 0, 1], 'labels': [1, 1, 1]}], tokenizer=tokenizer, config=config)
    with pytest.raises(ValueError):
        dataset_loader.get_train_dataloaders(batch_size=1)

def test_dataset_loader_get_val_dataloaders_invalid_batch_size():
    # Test get_val_dataloaders with invalid batch size
    config = get_config()
    tokenizer = get_tokenizer()
    dataset_loader = DatasetLoader(data