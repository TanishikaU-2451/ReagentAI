import pytest
import torch
from torch.utils.data import Dataset, DataLoader
from src.utils import Model, BertSelfAttention, BertFeedForward, BertClassifier

@pytest.fixture
def model():
    return Model(config={'self_attention': {'hidden_size': 768, 'dropout': 0.1}, 'feed_forward': {'hidden_size': 768, 'dropout': 0.1}, 'classifier': {'hidden_size': 768, 'dropout': 0.1}})

@pytest.fixture
def tokenizer():
    return BertTokenizer.from_pretrained('bert-base-uncased')

def test_model(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    attention_mask = torch.randn(1, 1, 512)
    output = model(input_ids, attention_mask)
    assert output.shape == (1, 1, 512)

def test_bert_self_attention(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    key = torch.randn(1, 1, 512)
    value = torch.randn(1, 1, 512)
    attention = model.bert_self_attention(input_ids, key, value)
    assert attention.shape == (1, 1, 512)

def test_bert_feed_forward(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_feed_forward(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier(model, tokenizer):
    input_ids = torch.randn(1, 1, 512)
    output = model.bert_classifier(input_ids)
    assert output.shape == (1, 1, 512)

def test_bert_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier_classifier