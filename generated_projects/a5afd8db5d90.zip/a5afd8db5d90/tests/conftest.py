import pytest
from conftest import Hyperparameters
from src.model import Model
from src.trainer import Trainer
from src.dataset_loader import Dataset
from src.trainer import GradScaler
from transformers import BertTokenizer, BertModel
from torch.utils.data import DataLoader
from torch.cuda.amp import GradScaler
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import Dataset, DataLoader
from typing import Dict, Any, List

@pytest.fixture
def config():
    """Config dictionary for the project."""
    return {
        "learning_rate": 0.001,
        "batch_size": 32,
        "epochs": 12,
        "optimizer": "Adam",
        "max_length": 512,
        "self_attention": True,
        "feed_forward": True,
        "dropout": 0.1,
        "dropout2": 0.1,
        "classifier": True,
        "classifier2": True,
        "classifier3": True,
        "classifier4": True,
        "classifier5": True,
        "classifier6": True,
        "classifier7": True,
        "classifier8": True,
        "classifier9": True,
        "classifier10": True,
        "classifier11": True,
        "classifier12": True,
        "classifier13": True,
        "classifier14": True,
        "classifier15": True,
        "classifier16": True,
        "classifier17": True,
        "classifier18": True,
        "classifier19": True,
        "classifier20": True,
        "classifier21": True,
        "classifier22": True,
        "classifier23": True,
        "classifier24": True,
        "classifier25": True
    }

@pytest.fixture
def dataset():
    """Mock dataset for testing."""
    data = [
        {"input_ids": [1, 2, 3], "attention_mask": [0, 0, 1], "labels": [1, 1, 1]},
        {"input_ids": [4, 5, 6], "attention_mask": [1, 1, 0], "labels": [1, 1, 1]},
        {"input_ids": [7, 8, 9], "attention_mask": [0, 0, 1], "labels": [1, 1, 1]},
        {"input_ids": [10, 11, 12], "attention_mask": [1, 1, 0], "labels": [1, 1, 1]},
        {"input_ids": [13, 14, 15], "attention_mask": [0, 0, 1], "labels": [1, 1, 1]},
        {"input_ids": [16, 17, 18], "attention_mask": [1, 1, 0], "labels": [1, 1, 1]},
        {"input_ids": [19, 20, 21], "attention_mask": [0, 0, 1], "labels": [1, 1, 1]},
        {"input_ids": [22, 23, 24], "attention_mask": [1, 1, 0], "labels": [1, 1, 1]},
        {"input_ids": [25, 26, 27], "attention_mask": [0, 0, 1], "labels": [1, 1, 1]}
    ]
    return Dataset(data, tokenizer=BertTokenizer.from_pretrained('bert-base-uncased'), config=config)

@pytest.fixture
def trainer(config):
    """Trainer fixture for testing."""
    model = Model(config)
    optimizer = Adam(model.parameters(), lr=config["learning_rate"])
    scaler = GradScaler()
    return Trainer(model, optimizer, DataLoader(Dataset(data, tokenizer=BertTokenizer.from_pretrained('bert-base-uncased'), config=config), config=config), config=config)

@pytest.fixture
def device():
    """Device fixture for testing."""
    if torch.cuda.is_available():
        return torch.device("cuda:0")
    else:
        return torch.device("cpu")

@pytest.fixture
def dataloader():
    """Dataloader fixture for testing."""
    return DataLoader(Dataset(data, tokenizer=BertTokenizer.from_pretrained('bert-base-uncased'), config=config), batch_size=config["batch_size"], shuffle=True)