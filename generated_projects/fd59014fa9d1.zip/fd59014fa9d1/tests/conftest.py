import pytest
from conftest import config, sample_input, mock_dataset
from src.model import Model
from src.trainer import Trainer

@pytest.fixture
def config_dict():
    """Sample config dict matching the project's config.yaml structure."""
    return {
        "learning_rate": 0.01,
        "batch_size": 32,
        "epochs": 100,
        "optimizer": "Adam",
        "other": {}
    }

@pytest.fixture
def sample_input():
    """A sample random input tensor for model forward-pass testing."""
    return torch.randn(1, 64)

@pytest.fixture
def mock_dataset():
    """A mock dataset with a few synthetic samples."""
    return mock_dataset()

@pytest.fixture
def device():
    """Device fixture (cpu for CI, cuda if available)."""
    import torch
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
    return device

def test_model(config_dict, sample_input, mock_dataset, device):
    """Test the model."""
    model = Model(config_dict)
    model.train()
    output = model(sample_input, device=device)
    assert output.shape == (1, 64)