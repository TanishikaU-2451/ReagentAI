import os
import sys
# Check if Docker is installed correctly
if not os.path.exists('/usr/bin/docker'):
    print('Error: Docker is not installed correctly. Please install Docker and try again.')