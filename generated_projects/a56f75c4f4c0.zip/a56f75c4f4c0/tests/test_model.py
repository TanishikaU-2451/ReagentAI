import pytest
import torch
from dataclasses import dataclass
from typing import Dict, List
from transformers import BertTokenizer, BertModel
from model import PaperImplConfig, PaperImpl, PaperImplDataset
from conftest import get_tokenizer, get_dataset

@pytest.fixture
def config():
    return PaperImplConfig()

@pytest.fixture
def tokenizer():
    return get_tokenizer()

@pytest.fixture
def dataset():
    return PaperImplDataset(['example1', 'example2', 'example3'], tokenizer)

@pytest.fixture
def model():
    return PaperImpl(config)

@pytest.fixture
def optimizer():
    return optim.Adam(model.parameters(), lr=0.001)

def test_paper_impl_config(config):
    assert isinstance(config, PaperImplConfig)
    assert config.learning_rate == 0.001
    assert config.batch_size == 32
    assert config.epochs == 12
    assert config.optimizer == "Adam"

def test_paper_impl(config):
    model = PaperImpl(config)
    assert isinstance(model, PaperImpl)
    assert hasattr(model, 'self_attention')
    assert hasattr(model, 'feed_forward')

def test_paper_impl_forward(config):
    model = PaperImpl(config)
    input_ids = torch.randn(1, 512)
    attention_mask = torch.randn(1, 512)
    outputs = model(input_ids, attention_mask)
    assert outputs.shape == (1, 512)

def test_paper_impl_model_summary(config):
    model = PaperImpl(config)
    model.model_summary()
    assert model.self_attention.weight.shape == (512, 512)
    assert model.feed_forward.weight.shape == (512, 512)

def test_paper_impl_dataset(dataset):
    dataset = PaperImplDataset(dataset.data, tokenizer)
    assert isinstance(dataset, PaperImplDataset)
    assert len(dataset) == len(dataset.data)

def test_paper_impl_dataset_len(dataset):
    dataset = PaperImplDataset(dataset.data, tokenizer)
    assert len(dataset) == len(dataset.data)

def test_paper_impl_dataset_getitem(dataset):
    dataset = PaperImplDataset(dataset.data, tokenizer)
    input_ids = dataset.data[0]
    attention_mask = dataset.data[0]['attention_mask']
    labels = dataset.data[0]['labels']
    assert input_ids.shape == (1, 512)
    assert attention_mask.shape == (1, 512)
    assert labels.shape == (1)

def test_paper_impl_train(model, config, optimizer, dataset):
    model.train()
    for epoch in range(config.epochs):
        for batch in dataset:
            input_ids = batch['input_ids'].to(config.device)
            attention_mask = batch['attention_mask'].to(config.device)
            labels = batch['labels'].to(config.device)
            optimizer.zero_grad()
            outputs = model(input_ids, attention_mask)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
    model.model_summary()
    assert model.loss.item() == 0

def test_paper_impl_main():
    config = PaperImplConfig()
    model = PaperImpl(config)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    main()
    assert model is not None

def test_paper_impl_default_config():
    model = PaperImpl(config)
    assert model.config.learning_rate == 0.001
    assert model.config.batch_size == 32
    assert model.config.epochs == 12
    assert model.config.optimizer == "Adam"