import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel
from typing import Dict, List
from dataclasses import dataclass
from dataclasses import dataclass
from torch.cuda.amp import GradScaler
from trainer import Trainer
from model import PaperImpl
from src.utils import PaperImplConfig, PaperImplDataset, PaperImplConfig as Config

class PaperImplConfig:
    def __init__(self, learning_rate: float = 0.001, batch_size: int = 32, epochs: int = 12, optimizer: str = "Adam"):
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.epochs = epochs
        self.optimizer = optimizer

class PaperImpl(nn.Module):
    def __init__(self, config: PaperImplConfig):
        super(PaperImpl, self).__init__()
        self.config = config
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.model = BertModel.from_pretrained('bert-base-uncased')
        self.self_attention = nn.MultiHeadAttention(512, 512)
        self.feed_forward = nn.Linear(512, 512)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.model(input_ids, attention_mask=attention_mask)
        attention_weights = self.self_attention(outputs, outputs)
        outputs = self.feed_forward(outputs)
        return outputs

class Trainer:
    def __init__(self, config: PaperImplConfig):
        self.config = config
        self.model = PaperImpl(config)
        self.optimizer = optim.Adam(self.model.parameters(), lr=config.learning_rate)
        self.dataloader = DataLoader(
            PaperImplConfig(),
            batch_size=config.batch_size,
            shuffle=True,
            num_workers=0,
        )
        self.scaler = GradScaler()
        self.log_dir = f"logs/trainer/{config.config.name}"

    def train(self):
        for epoch in range(self.config.epochs):
            self.model.train()
            total_loss = 0
            for batch in self.dataloader:
                input_ids = batch['input_ids'].to('cuda')
                attention_mask = batch['attention_mask'].to('cuda')
                optimizer = self.optimizer
                optimizer.zero_grad()
                outputs = self.model(input_ids, attention_mask=attention_mask)
                loss = nn.CrossEntropyLoss()(outputs, batch['labels'].to('cuda'))
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
            self.scaler.scale = total_loss / self.config.epochs
            self.scaler.step(optimizer)
            self.scaler.update()

def main():
    config = Config()
    trainer = Trainer(config)
    trainer.train()

if __name__ == "__main__":
    main()