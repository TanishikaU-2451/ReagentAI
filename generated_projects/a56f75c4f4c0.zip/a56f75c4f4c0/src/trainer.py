src/trainer.py
```python
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel
from typing import Dict, List
from dataclasses import dataclass
from torch.cuda.amp import GradScaler
from trainer import PaperImplConfig
from model import PaperImpl

@dataclass
class Trainer:
    def __init__(self, config: PaperImplConfig):
        self.config = config
        self.model = PaperImpl(config)
        self.optimizer = optim.Adam(self.model.parameters(), lr=config.learning_rate)
        self.dataloader = DataLoader(
            PaperImplConfig(),
            batch_size=config.batch_size,
            shuffle=True,
            num_workers=0,
        )
        self.scaler = GradScaler()
        self.log_dir = f"logs/trainer/{config.config.name}"

    def train(self):
        for epoch in range(self.config.epochs):
            print(f"Epoch {epoch+1}/{self.config.epochs}")
            for batch in self.dataloader:
                input_ids = batch['input_ids'].to('cuda' if torch.cuda.is_available() else 'cpu')
                attention_mask = batch['attention_mask'].to('cuda' if torch.cuda.is_available() else 'cpu')
                optimizer = self.optimizer
                optimizer.zero_grad()
                outputs = self.model(input_ids, attention_mask=attention_mask)
                loss = outputs.loss
                loss.backward()
                self.optimizer.step()
                self.scaler.scale(loss).backward()
                self.scaler.step(optimizer)
                self.scaler.update()
                print(f"Batch Loss: {loss.item():.4f}")
                print(f"Memory Usage: {torch.cuda.memory_usage('cuda') / (1024 * 1024):.2f} MB")
                print()

    def evaluate(self):
        total_loss = 0
        for batch in self.dataloader:
            input_ids = batch['input_ids'].to('cuda' if torch.cuda.is_available() else 'cpu')
            attention_mask = batch['attention_mask'].to('cuda' if torch.cuda.is_available() else 'cpu')
            optimizer = self.optimizer
            optimizer.zero_grad()
            outputs = self.model(input_ids, attention_mask=attention_mask)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        average_loss = total_loss / len(self.dataloader)
        print(f"Average Loss: {average_loss:.4f}")
        print(f"Memory Usage: {torch.cuda.memory_usage('cuda') / (1024 * 1024):.2f} MB")

    def save_checkpoint(self, checkpoint_path):
        torch.save({
            'model': self.model.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'config': self.config,
        }, checkpoint_path)
```

src/model.py
```python
import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertModel
from typing import Dict
from dataclasses import dataclass

@dataclass
class PaperImplConfig:
    learning_rate: float = 0.001
    batch_size: int = 32
    epochs: int = 12
    optimizer: str = "Adam"

class PaperImpl(nn.Module):
    def __init__(self, config: PaperImplConfig):
        super(PaperImpl, self).__init__()
        self.config = config
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.model = BertModel.from_pretrained('bert-base-uncased')
        self.self_attention = nn.MultiHeadAttention(512, 512)
        self.feed_forward = nn.Linear(512, 512)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.model(input_ids, attention_mask=attention_mask)
        attention_weights = self.self_attention(outputs, outputs)
        outputs = self.feed_forward(outputs)
        return outputs