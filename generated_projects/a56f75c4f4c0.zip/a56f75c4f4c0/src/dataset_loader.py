src/dataset_loader.py
```python
import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertModel
from typing import Dict, List
from dataclasses import dataclass
from dataclasses import dataclass
from torch.utils.data import Dataset, DataLoader
from torch.cuda.amp import GradScaler
from trainer import Trainer
from model import PaperImpl

@dataclass
class PaperImplConfig:
    learning_rate: float = 0.001
    batch_size: int = 32
    epochs: int = 12
    optimizer: str = "Adam"

class PaperImplDataset(Dataset):
    def __init__(self, data: List[Dict[str, str]], tokenizer: BertTokenizer):
        self.data = data
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        input_ids = self.tokenizer.encode_plus(
            self.data[idx]["text"],
            max_length=512,
            padding="max_length",
            truncation=True,
            return_attention_mask=True,
            return_tensors="pt",
        )
        attention_mask = self.tokenizer.encode_plus(
            self.data[idx]["text"],
            max_length=512,
            padding="max_length",
            truncation=True,
            return_attention_mask=True,
            return_tensors="pt",
        )
        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": self.data[idx]["label"],
        }

class PaperImplDataLoader(DataLoader):
    def __init__(self, data: List[Dict[str, str]], tokenizer: BertTokenizer, config: PaperImplConfig):
        super(PaperImplDataLoader, self).__init__(
            data,
            batch_size=config.batch_size,
            shuffle=config.shuffle,
            num_workers=0,
            pin_memory=True,
            drop_last=config.drop_last,
            collate_fn=self.data_collate,
        )
        self.tokenizer = tokenizer
        self.config = config

    def data_collate(self, data):
        return self.tokenizer.encode_plus(
            torch.stack([item["text"] for item in data]),
            max_length=512,
            padding="max_length",
            truncation=True,
            return_attention_mask=True,
            return_tensors="pt",
        )

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]
```

src/model.py
```python
import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertModel
from typing import Dict, List
from dataclasses import dataclass
from dataclasses import dataclass
from torch.utils.data import Dataset, DataLoader
from trainer import Trainer
from dataset_loader import PaperImplDataset
from paper_impl_config import PaperImplConfig

@dataclass
class PaperImplConfig:
    learning_rate: float = 0.001
    batch_size: int = 32
    epochs: int = 12
    optimizer: str = "Adam"

class PaperImpl(nn.Module):
    def __init__(self, config: PaperImplConfig):
        super(PaperImpl, self).__init__()
        self.config = config
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.model = BertModel.from_pretrained('bert-base-uncased')
        self.self_attention = nn.MultiHeadAttention(512, 512)
        self.feed_forward = nn.Linear(512, 512)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.model(input_ids, attention_mask=attention_mask)
        attention_weights = self.self_attention(outputs, outputs)
        outputs = self.feed_forward(outputs)
        return outputs
```

src/trainer.py
```python
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel
from typing import Dict, List
from dataclasses import dataclass
from torch.cuda.amp import GradScaler
from paper_impl_config import PaperImplConfig
from model import PaperImpl
from dataset_loader import PaperImplDataset
from trainer import Trainer
from paper_impl_dataset import PaperImplDataset

@dataclass
class Trainer:
    def __init__(self, config: PaperImplConfig):
        self.config = config
        self.model = PaperImpl(config)
        self.optimizer = optim.Adam(self.model.parameters(), lr=config.learning_rate)
        self.dataloader = DataLoader(
            PaperImplDataset(self.config.data, self.tokenizer),
            batch_size=config.batch_size,
            shuffle=config.shuffle,
            num_workers=0,
            pin_memory=True,
            drop_last=config.drop_last,
            collate_fn=self.data_collate,
        )
        self.scaler = GradScaler()
        self.log_dir = f"logs/trainer/{config.config.name}"

    def train(self):
        for epoch in range(self.config.epochs):
            for batch_idx, (inputs, attention_mask, labels) in enumerate(self.dataloader):
                self.optimizer.zero_grad()
                outputs = self.model(inputs, attention_mask=attention_mask)
                loss = outputs.mean()
                loss.backward()
                self.optimizer.step()
                self.scaler.scale(loss).backward()
                self.scaler.step(loss)
                print(f"Epoch {epoch+1}, Batch {batch_idx+1}, Loss: {loss.item():.4f}")
```

src/paper_impl_dataset.py
```python
import torch
import torch.nn as nn
import torch.optim as optim
from transformers import BertTokenizer, BertModel
from typing import Dict, List
from dataclasses import dataclass
from dataclasses import dataclass
from torch.utils.data import Dataset, DataLoader
from trainer import Trainer
from model import PaperImpl

@dataclass
class PaperImplDataset(Dataset):
    data: List[Dict[str, str]]
    tokenizer: BertTokenizer

    def __init__(self, data: List[Dict[str, str]], tokenizer: BertTokenizer):
        self.data = data
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        input_ids = self.tokenizer.encode_plus(
            self.data[idx]["text"],
            max_length=512,
            padding="max_length",
            truncation=True,
            return_attention_mask=True,
            return_tensors="pt",
        )
        attention_mask = self.tokenizer.encode_plus(
            self.data[idx]["text"],
            max_length=512,
            padding="max_length",
            truncation=True,
            return_attention_mask=True,
            return_tensors="pt",
        )
        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": self.data[idx]["label"],
        }