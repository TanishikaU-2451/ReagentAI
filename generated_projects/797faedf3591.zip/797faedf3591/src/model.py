import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from typing import Dict, List
from src.utils import load_dataset, prepare_data, model_summary

class Model(nn.Module):
    def __init__(self, config: Dict):
        super(Model, self).__init__()
        self.config = config
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = NeuralNetwork(config)
        self.decision_tree = DecisionTreeRegressor(config)
        self.random_forest = RandomForestRegressor(config)

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        attention_output = self.attention(x)
        embeddings_output = self.embeddings(x)
        neural_network_output = self.neural_network(x, y)
        decision_tree_output = self.decision_tree(x)
        random_forest_output = self.random_forest(x)
        return attention_output + embeddings_output + neural_network_output + decision_tree_output + random_forest_output + self.config['b']

class Attention(nn.Module):
    def __init__(self, config: Dict):
        super(Attention, self).__init__()
        self.config = config
        self.weights = nn.Parameter(torch.randn(config['n_features'], config['n_heads']))
        self.dropout = nn.Dropout(config['dropout'])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weights = torch.matmul(x, self.weights) / math.sqrt(config['n_heads'])
        weights = self.dropout(weights)
        return torch.tanh(weights)

class Embeddings(nn.Module):
    def __init__(self, config: Dict):
        super(Embeddings, self).__init__()
        self.config = config
        self.weights = nn.Parameter(torch.randn(config['n_features'], config['n_dim']))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.matmul(x, self.weights)

class NeuralNetwork(nn.Module):
    def __init__(self, config: Dict):
        super(NeuralNetwork, self).__init__()
        self.config = config
        self.weights1 = nn.Parameter(torch.randn(config['n_features'], config['n_features']))
        self.weights2 = nn.Parameter(torch.randn(config['n_features'], config['n_features']))
        self.bias1 = nn.Parameter(torch.randn(config['n_features']))
        self.bias2 = nn.Parameter(torch.randn(config['n_features']))
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        x = torch.matmul(x, self.weights1) + self.bias1
        x = self.relu(x)
        x = torch.matmul(x, self.weights2) + self.bias2
        return x

class DecisionTreeRegressor(nn.Module):
    def __init__(self, config: Dict):
        super(DecisionTreeRegressor, self).__init__()
        self.config = config
        self.tree = DecisionTreeRegressor(config)

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return self.tree(x, y)

class RandomForestRegressor(nn.Module):
    def __init__(self, config: Dict):
        super(RandomForestRegressor, self).__init__()
        self.config = config
        self.tree = RandomForestRegressor(config)

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return self.tree(x, y)