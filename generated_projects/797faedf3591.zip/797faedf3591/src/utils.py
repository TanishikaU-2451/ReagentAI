import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, List
from src.utils import load_dataset, prepare_data, model_summary
from src.model import Model
from src.dataset_loader import DatasetLoader
from src.attention import Attention
from src.embeddings import Embeddings
from src.neural_network import NeuralNetwork
from src.decision_tree import DecisionTreeRegressor
from src.random_forest import RandomForestRegressor

class Model(nn.Module):
    """
    Multiple Linear Regression model with attention, embeddings, neural network, decision tree, and random forest components.
    """
    def __init__(self, config: Dict):
        """
        Initializes the model with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters and training strategy.
        """
        super(Model, self).__init__()
        self.config = config
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = NeuralNetwork(config)
        self.decision_tree = DecisionTreeRegressor(config)
        self.random_forest = RandomForestRegressor(config)

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Defines the forward pass of the model.

        Args:
            x (torch.Tensor): Input data.
            y (torch.Tensor): Target data.

        Returns:
            torch.Tensor: Predicted output.
        """
        attention_output = self.attention(x)
        embeddings_output = self.embeddings(x)
        neural_network_output = self.neural_network(x, y)
        decision_tree_output = self.decision_tree(x)
        random_forest_output = self.random_forest(x)
        return attention_output + embeddings_output + neural_network_output + decision_tree_output + random_forest_output + self.config['b']

class DatasetLoader(nn.Module):
    """
    Dataset loader class for loading and preprocessing data.
    """
    def __init__(self, config: Dict):
        """
        Initializes the dataset loader with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters.
        """
        super(DatasetLoader, self).__init__()
        self.config = config
        self.train_dataset = None
        self.val_dataset = None
        self.test_dataset = None

    def get_dataloaders(self) -> Dict:
        """
        Returns a dictionary of dataloaders for training, validation, and testing datasets.

        Returns:
            Dict: Dictionary of dataloaders.
        """
        if self.train_dataset is None:
            self.train_dataset, self.val_dataset, self.test_dataset = load_dataset(self.config)
        return {
            'train': self.train_dataset,
            'val': self.val_dataset,
            'test': self.test_dataset
        }

class Attention(nn.Module):
    """
    Attention component for the model.
    """
    def __init__(self, config: Dict):
        """
        Initializes the attention component with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters.
        """
        super(Attention, self).__init__()
        self.config = config
        self.weights = nn.Parameter(torch.randn(config['n_features'], config['n_heads']))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Defines the forward pass of the attention component.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Attention output.
        """
        return torch.matmul(x, self.weights) / math.sqrt(config['n_heads'])

class Embeddings(nn.Module):
    """
    Embeddings component for the model.
    """
    def __init__(self, config: Dict):
        """
        Initializes the embeddings component with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters.
        """
        super(Embeddings, self).__init__()
        self.config = config
        self.weights = nn.Parameter(torch.randn(config['n_features'], config['n_features']))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Defines the forward pass of the embeddings component.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Embeddings output.
        """
        return torch.matmul(x, self.weights)

class NeuralNetwork(nn.Module):
    """
    Neural network component for the model.
    """
    def __init__(self, config: Dict):
        """
        Initializes the neural network component with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters.
        """
        super(NeuralNetwork, self).__init__()
        self.config = config
        self.weights = nn.Parameter(torch.randn(config['n_features'], config['n_features']))
        self.bias = nn.Parameter(torch.randn(config['n_features']))

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Defines the forward pass of the neural network component.

        Args:
            x (torch.Tensor): Input data.
            y (torch.Tensor): Target data.

        Returns:
            torch.Tensor: Predicted output.
        """
        return torch.matmul(x, self.weights) + self.bias

class DecisionTreeRegressor(nn.Module):
    """
    Decision tree regressor component for the model.
    """
    def __init__(self, config: Dict):
        """
        Initializes the decision tree regressor component with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters.
        """
        super(DecisionTreeRegressor, self).__init__()
        self.config = config
        self.tree = DecisionTreeRegressor(config)

    def fit(self, x: torch.Tensor, y: torch.Tensor) -> None:
        """
        Fits the decision tree regressor component.

        Args:
            x (torch.Tensor): Input data.
            y (torch.Tensor): Target data.
        """
        self.tree.fit(x, y)

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        """
        Predicts the target data using the decision tree regressor component.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Predicted output.
        """
        return self.tree.predict(x)

class RandomForestRegressor(nn.Module):
    """
    Random forest regressor component for the model.
    """
    def __init__(self, config: Dict):
        """
        Initializes the random forest regressor component with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters.
        """
        super(RandomForestRegressor, self).__init__()
        self.config = config
        self.tree = RandomForestRegressor(config)

    def fit(self, x: torch.Tensor, y: torch.Tensor) -> None:
        """
        Fits the random forest regressor component.

        Args:
            x (torch.Tensor): Input data.
            y (torch.Tensor): Target data.
        """
        self.tree.fit(x, y)

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        """
        Predicts the target data using the random forest regressor component.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Predicted output.
        """
        return self.tree.predict(x)

class Model(nn.Module):
    """
    Multiple Linear Regression model with attention, embeddings, neural network, decision tree, and random forest components.
    """
    def __init__(self, config: Dict):
        """
        Initializes the model with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters.
        """
        super(Model, self).__init__()
        self.config = config
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = NeuralNetwork(config)
        self.decision_tree = DecisionTreeRegressor(config)
        self.random_forest = RandomForestRegressor(config)

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Defines the forward pass of the model.

        Args:
            x (torch.Tensor): Input data.
            y (torch.Tensor): Target data.

        Returns:
            torch.Tensor: Predicted output.
        """
        attention_output = self.attention(x)
        embeddings_output = self.embeddings(x)
        neural_network_output = self.neural_network(x, y)
        decision_tree_output = self.decision_tree(x)
        random_forest_output = self.random_forest(x)
        return attention_output + embeddings_output + neural_network_output + decision_tree_output + random_forest_output + self.config['b']

class DatasetLoader(nn.Module):
    """
    Dataset loader class for loading and preprocessing data.
    """
    def __init__(self, config: Dict):
        """
        Initializes the dataset loader with the given configuration.

        Args:
            config (Dict): Configuration dictionary containing hyperparameters.
        """
        super(DatasetLoader, self).__init__()
        self.config = config
        self.train_dataset = None
        self.val_dataset = None
        self.test_dataset = None

    def get_dataloaders(self) -> Dict:
        """
        Returns a dictionary of dataloaders for training, validation, and testing datasets.

        Returns:
            Dict: Dictionary of dataloaders.
        """
        if self.train_dataset is None:
            self.train_dataset, self.val_dataset, self.test_dataset = load_dataset(self.config)
        return {
            'train': self.train_dataset,
            'val': self.val_dataset,
            'test': self.test_dataset
        }

def main():
    # Load configuration
    config = {
        "learning_rate": 0.01,
        "batch_size": 32,
        "epochs": 100,
        "optimizer": "adam"
    }

    # Create dataset loader
    dataset_loader = DatasetLoader(config)

    # Create model
    model = Model(config)

    # Train model
    model.fit(dataset_loader.get_dataloaders())

    # Evaluate model
    model.evaluate(dataset_loader.get_dataloaders())

    # Inference
    inference = model.predict(dataset_loader.get_dataloaders())

    # Save model
    torch.save(model.state_dict(), "model.pth")

if __name__ == "__main__":
    main()