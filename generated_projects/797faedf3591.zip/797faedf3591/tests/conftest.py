import pytest
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from typing import Dict, List
from src.utils import load_dataset, prepare_data, model_summary
from src.model import Model
from src.dataset_loader import DatasetLoader
from src.attention import Attention
from src.embeddings import Embeddings
from src.neural_network import NeuralNetwork
from src.decision_tree import DecisionTreeRegressor
from src.random_forest import RandomForestRegressor

@pytest.fixture
def config():
    """
    Returns a sample config dict matching the project's config.yaml structure.

    Returns:
        Dict: Sample configuration dictionary.
    """
    return {
        "learning_rate": 0.01,
        "batch_size": 32,
        "epochs": 100,
        "optimizer": "adam",
        "n_features": 10,
        "n_heads": 8,
        "dropout": 0.2,
        "b": 1
    }

@pytest.fixture
def sample_input():
    """
    Returns a small random input tensor for model forward-pass testing.

    Returns:
        torch.Tensor: Sample input tensor.
    """
    return torch.randn(1, 10)

@pytest.fixture
def dataset():
    """
    Returns a mock dataset with a few synthetic samples.

    Returns:
        Dataset: Mock dataset.
    """
    return DatasetLoader(config={"n_features": 10, "n_heads": 8, "dropout": 0.2, "b": 1})

@pytest.fixture
def device():
    """
    Returns a device fixture (cpu for CI, cuda if available).

    Returns:
        torch.device: Device to run the model on.
    """
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")

@pytest.fixture
def model():
    """
    Returns a sample model instance.

    Returns:
        Model: Sample model instance.
    """
    return Model(config=config)