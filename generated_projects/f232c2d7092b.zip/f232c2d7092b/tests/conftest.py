import pytest
from conftest import config, sample_input_tensor, mock_dataset, device

@pytest.fixture
def config_dict():
    """
    A sample config dict matching the project's config.yaml structure.
    """
    return {
        "learning_rate": 0.01,
        "batch_size": 32,
        "epochs": 10,
        "optimizer": "Adam",
        "other": {}
    }

@pytest.fixture
def sample_input_tensor():
    """
    A sample input tensor for model forward-pass testing.
    """
    return torch.randn(1, 10)

@pytest.fixture
def mock_dataset():
    """
    A mock dataset with a few synthetic samples.
    """
    data = {
        "features": torch.randn(100, 10),
        "labels": torch.randn(100)
    }
    return mock_dataset(data)

@pytest.fixture
def device():
    """
    A device fixture (cpu for CI, cuda if available).
    """
    if torch.cuda.is_available():
        return torch.device("cuda")
    else:
        return torch.device("cpu")