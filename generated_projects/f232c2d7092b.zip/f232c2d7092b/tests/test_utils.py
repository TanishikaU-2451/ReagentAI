import pytest
import numpy as np
import torch
from torch import nn
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from conftest import *

def test_trainer():
    model = nn.Linear(5, 3)
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    dataloader = DataLoader([torch.randn(1, 5)], [torch.randn(1, 3)])
    trainer = Trainer(model, optimizer, dataloader, {"epochs": 100})
    trainer.train()
    assert trainer.model.parameters().shape == (5, 3)
    assert trainer.optimizer.parameters().shape == (5, 0.01)

def test_neural_network():
    model = nn.Linear(5, 3)
    inputs = torch.randn(1, 5)
    outputs = model(inputs)
    assert outputs.shape == (1, 3)

def test_linear_regression():
    model = LinearRegression(input_dim=5, output_dim=3)
    inputs = torch.randn(1, 5)
    outputs = model(inputs)
    assert outputs.shape == (1, 3)

def test_dataset_loader():
    data = np.load("data.npy")
    labels = np.load("labels.npy")
    dataloader = DataLoader(data, labels, train_size=0.8, val_size=0.1, test_size=0.1)
    assert len(dataloader) == 1000
    assert len(dataloader.data) == 1000
    assert len(dataloader.labels) == 1000

def test_model():
    model = nn.Linear(5, 3)
    model.load_state_dict(torch.load("model.pth"))
    model.eval()
    inputs = torch.randn(1, 5)
    outputs = model(inputs)
    assert outputs.shape == (1, 3)

def test_trainer_default_config():
    trainer = Trainer(model, optim.Adam(model.parameters(), lr=0.01), dataloader, {})
    assert trainer.config["epochs"] == 100
    assert trainer.config["batch_size"] == 32

def test_train_step():
    trainer = Trainer(model, optim.Adam(model.parameters(), lr=0.01), dataloader, {})
    trainer.train()
    assert len(trainer.dataloader) == 1000
    assert len(trainer.dataloader.data) == 1000
    assert len(trainer.dataloader.labels) == 1000

def test_forward_pass_random_input():
    model = nn.Linear(5, 3)
    inputs = torch.randn(1, 5)
    outputs = model(inputs)
    assert outputs.shape == (1, 3)

def test_gradient_flow():
    model = nn.Linear(5, 3)
    inputs = torch.randn(1, 5)
    outputs = model(inputs)
    loss = nn.MSELoss()(outputs, torch.randn(1, 3))
    loss.backward()
    assert torch.allclose(model.parameters(), torch.zeros_like(model.parameters()))

def test_dataset_loader_empty_input():
    dataloader = DataLoader([torch.randn(1, 5)], [torch.randn(1, 3)])
    with pytest.raises(ValueError):
        dataloader.__len__()

def test_dataset_loader_single_sample():
    dataloader = DataLoader([torch.randn(1, 5)], [torch.randn(1, 3)])
    assert len(dataloader) == 1
    assert len(dataloader.data) == 1
    assert len(dataloader.labels) == 1

def test_dataset_loader_batch_of_1():
    dataloader = DataLoader([torch.randn(1, 5)], [torch.randn(1, 3)])
    assert len(dataloader) == 1
    assert len(dataloader.data) == 1
    assert len(dataloader.labels) == 1