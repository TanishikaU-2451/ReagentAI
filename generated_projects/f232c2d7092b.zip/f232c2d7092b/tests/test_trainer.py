import pytest
import torch
from torch import nn
from torch.optim import Adam
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
import numpy as np
import logging
from src.trainer import Trainer, Model, LinearRegression, Dataset, DataLoader
from src.test_utils import create_dataset, create_dataloader, create_model, create_optimizer, create_logger

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_trainer():
    # Test that a single training step runs without error
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    trainer = Trainer(model, optimizer, create_dataloader(), {"epochs": 10})
    trainer.train()
    assert False, "Training should have raised an exception"

    # Test that a single training step runs without error
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    trainer = Trainer(model, optimizer, create_dataloader(), {"epochs": 10})
    trainer.train()
    assert False, "Training should have raised an exception"

    # Test that a single training step runs without error
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    trainer = Trainer(model, optimizer, create_dataloader(), {"epochs": 10})
    trainer.train()
    assert False, "Training should have raised an exception"

def test_model():
    # Test that a model can be instantiated with default config
    model = create_model()
    assert model is not None, "Model should not be None"

    # Test that a model can be instantiated with default config
    model = create_model()
    assert model.input_dim == 10, "Input dimension should be 10"
    assert model.hidden_dim == 10, "Hidden dimension should be 10"
    assert model.output_dim == 1, "Output dimension should be 1"

    # Test that a model can be instantiated with default config
    model = create_model()
    assert model.fc1.in_features == 10, "Input features should be 10"
    assert model.fc2.in_features == 10, "Hidden features should be 10"
    assert model.fc3.in_features == 10, "Output features should be 10"

def test_linear_regression():
    # Test that a linear regression model can be instantiated with default config
    model = create_model()
    assert model.weights.shape == (10, 1), "Weights should be 10x1"
    assert model.bias.shape == (1,), "Bias should be 1x1"

    # Test that a linear regression model can be instantiated with default config
    model = create_model()
    assert model.weights.shape == (10,), "Weights should be 10x1"
    assert model.bias.shape == (1,), "Bias should be 1x1"

    # Test that a linear regression model can be instantiated with default config
    model = create_model()
    assert model.weights.shape == (10,), "Weights should be 10x1"
    assert model.bias.shape == (1,), "Bias should be 1x1"

def test_dataset():
    # Test that a dataset can be created with default config
    dataset = create_dataset()
    assert dataset is not None, "Dataset should not be None"

    # Test that a dataset can be created with default config
    dataset = create_dataset()
    assert dataset.data.shape == (100, 10), "Data shape should be 100x10"
    assert dataset.labels.shape == (100,), "Labels shape should be 100x1"

    # Test that a dataset can be created with default config
    dataset = create_dataset()
    assert dataset.data.shape == (100, 10), "Data shape should be 100x10"
    assert dataset.labels.shape == (100,), "Labels shape should be 100x1"

    # Test that a dataset can be created with default config
    dataset = create_dataset()
    assert dataset.data.shape == (100,), "Data shape should be 100x10"
    assert dataset.labels.shape == (100,), "Labels shape should be 100x1"

def test_dataloader():
    # Test that a dataloader can be created with default config
    dataloader = create_dataloader()
    assert dataloader is not None, "Dataloader should not be None"

    # Test that a dataloader can be created with default config
    dataloader = create_dataloader()
    assert dataloader.data.shape == (100, 10), "Data shape should be 100x10"
    assert dataloader.labels.shape == (100,), "Labels shape should be 100x1"

    # Test that a dataloader can be created with default config
    dataloader = create_dataloader()
    assert dataloader.data.shape == (100,), "Data shape should be 100x10"
    assert dataloader.labels.shape == (100,), "Labels shape should be 100x1"

def test_model_forward_pass():
    # Test that a model can be forward passed with random input
    model = create_model()
    inputs = torch.randn(1, 10)
    outputs = model(inputs)
    assert outputs.shape == (1,), "Output shape should be 1x1"

    # Test that a model can be forward passed with random input
    model = create_model()
    inputs = torch.randn(1, 10)
    outputs = model(inputs)
    assert outputs.shape == (1,), "Output shape should be 1x1"

    # Test that a model can be forward passed with random input
    model = create_model()
    inputs = torch.randn(1, 10)
    outputs = model(inputs)
    assert outputs.shape == (1,), "Output shape should be 1x1"

def test_model_backward_pass():
    # Test that a model can be backward passed with random input
    model = create_model()
    inputs = torch.randn(1, 10)
    outputs = torch.randn(1, 1)
    loss = torch.randn(1, 1)
    loss.backward()
    assert False, "No error should have been raised"

def test_model_optimization():
    # Test that a model can be optimized with Adam optimizer
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    model.zero_grad()
    loss = torch.randn(1, 1)
    loss.backward()
    optimizer.step()
    assert False, "No error should have been raised"

def test_model_save():
    # Test that a model can be saved with default config
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    trainer = Trainer(model, optimizer, create_dataloader(), {"epochs": 10})
    trainer.save_checkpoint(model.state_dict())

def test_model_load():
    # Test that a model can be loaded with default config
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    trainer = Trainer(model, optimizer, create_dataloader(), {"epochs": 10})
    loaded_model = Trainer.load_model(model, optimizer, create_dataloader(), {"epochs": 10})
    assert loaded_model is not None, "Model should not be None"
    assert loaded_model.model is not None, "Model should not be None"
    assert loaded_model.optimizer is not None, "Optimizer should not be None"
    assert loaded_model.config["epochs"] == 10, "Epoch should be 10"

def test_model_shape_check():
    # Test that a model can be instantiated with default config
    model = create_model()
    assert model.input_dim == 10, "Input dimension should be 10"
    assert model.hidden_dim == 10, "Hidden dimension should be 10"
    assert model.output_dim == 1, "Output dimension should be 1"

    # Test that a model can be instantiated with default config
    model = create_model()
    assert model.fc1.in_features == 10, "Input features should be 10"
    assert model.fc2.in_features == 10, "Hidden features should be 10"
    assert model.fc3.in_features == 10, "Output features should be 10"

def test_linear_regression_shape_check():
    # Test that a linear regression model can be instantiated with default config
    model = create_model()
    assert model.weights.shape == (10, 1), "Weights should be 10x1"
    assert model.bias.shape == (1,), "Bias should be 1x1"

    # Test that a linear regression model can be instantiated with default config
    model = create_model()
    assert model.weights.shape == (10,), "Weights should be 10x1"
    assert model.bias.shape == (1,), "Bias should be 1x1"

    # Test that a linear regression model can be instantiated with default config
    model = create_model()
    assert model.weights.shape == (10,), "Weights should be 10x1"
    assert model.bias.shape == (1,), "Bias should be 1x1"

def test_linear_regression_type_check():
    # Test that a linear regression model can be instantiated with default config
    model = create_model()
    assert isinstance(model.weights, nn.Parameter), "Weights should be a Parameter"

    # Test that a linear regression model can be instantiated with default config
    model = create_model()
    assert isinstance(model.bias, nn.Parameter), "Bias should be a Parameter"

def test_dataset_shape_check():
    # Test that a dataset can be created with default config
    dataset = create_dataset()
    assert dataset is not None, "Dataset should not be None"

    # Test that a dataset can be created with default config
    dataset = create_dataset()
    assert dataset.data.shape == (100, 10), "Data shape should be 100x10"
    assert dataset.labels.shape == (100,), "Labels shape should be 100x1"

    # Test that a dataset can be created with default config
    dataset = create_dataset()
    assert dataset.data.shape == (100, 10), "Data shape should be 100x10"
    assert dataset.labels.shape == (100,), "Labels shape should be 100x1"

    # Test that a dataset can be created with default config
    dataset = create_dataset()
    assert dataset.data.shape == (100,), "Data shape should be 100x10"
    assert dataset.labels.shape == (100,), "Labels shape should be 100x1"

def test_dataloader_shape_check():
    # Test that a dataloader can be created with default config
    dataloader = create_dataloader()
    assert dataloader is not None, "Dataloader should not be None"

    # Test that a dataloader can be created with default config
    dataloader = create_dataloader()
    assert dataloader.data.shape == (100, 10), "Data shape should be 100x10"
    assert dataloader.labels.shape == (100,), "Labels shape should be 100x1"

    # Test that a dataloader can be created with default config
    dataloader = create_dataloader()
    assert dataloader.data.shape == (100,), "Data shape should be 100x10"
    assert dataloader.labels.shape == (100,), "Labels shape should be 100x1"

def test_model_forward_pass():
    # Test that a model can be forward passed with random input
    model = create_model()
    inputs = torch.randn(1, 10)
    outputs = model(inputs)
    assert outputs.shape == (1,), "Output shape should be 1x1"

    # Test that a model can be forward passed with random input
    model = create_model()
    inputs = torch.randn(1, 10)
    outputs = model(inputs)
    assert outputs.shape == (1,), "Output shape should be 1x1"

    # Test that a model can be forward passed with random input
    model = create_model()
    inputs = torch.randn(1, 10)
    outputs = model(inputs)
    assert outputs.shape == (1,), "Output shape should be 1x1"

def test_model_backward_pass():
    # Test that a model can be backward passed with random input
    model = create_model()
    inputs = torch.randn(1, 10)
    outputs = torch.randn(1, 1)
    loss = torch.randn(1, 1)
    loss.backward()
    assert False, "No error should have been raised"

def test_model_optimization():
    # Test that a model can be optimized with Adam optimizer
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    model.zero_grad()
    loss = torch.randn(1, 1)
    loss.backward()
    optimizer.step()
    assert False, "No error should have been raised"

def test_model_save():
    # Test that a model can be saved with default config
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    trainer = Trainer(model, optimizer, create_dataloader(), {"epochs": 10})
    trainer.save_checkpoint(model.state_dict())

def test_model_load():
    # Test that a model can be loaded with default config
    model = create_model()
    optimizer = Adam(model.parameters(), lr=0.01)
    trainer = Trainer(model, optimizer, create_dataloader(), {"epochs": 10})
    loaded_model = Trainer.load_model(model, optimizer, create_dataloader(), {"epochs": 10})
    assert loaded_model is not None, "Model should not be None"
    assert loaded_model.model is not None, "Model should not be None"
    assert loaded_model.optimizer is not None, "Optimizer should not be None"
    assert loaded_model.config["epochs"] == 10, "Epoch should be 10"

def test_model_shape_check():
    # Test that a model can be instantiated with default config
    model = create_model()
    assert model.input_dim == 10, "Input dimension should be 10"
    assert model.hidden_dim == 10, "Hidden dimension should be 10"
    assert model.output_dim == 1, "Output dimension should be 1"

    # Test that a model can be instantiated with default config
    model = create_model()
    assert model.fc1.in_features == 10, "Input features should be 10"
    assert model.fc2.in_features == 10, "Hidden features should be 10"
    assert model.fc3.in_features == 10, "