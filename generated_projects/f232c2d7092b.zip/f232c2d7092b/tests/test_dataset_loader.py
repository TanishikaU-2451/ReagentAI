import pytest
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
import numpy as np

@pytest.fixture
def dataset():
    data = np.random.rand(100, 10)
    labels = np.random.rand(100)
    return Dataset(data, labels)

@pytest.fixture
def dataset_loader(dataset):
    train_data, val_data, test_data = train_test_split(dataset.data, dataset.labels, test_size=0.1, random_state=42)
    return DataLoader(dataset, batch_size=32, shuffle=True)

class TestDataset:
    def test_init(self):
        dataset = Dataset(dataset_loader(dataset), dataset.labels)
        assert len(dataset) == 100
        assert len(dataset.data) == 100
        assert len(dataset.labels) == 100

    def test_len(self):
        dataset = Dataset(dataset_loader(dataset), dataset.labels)
        assert len(dataset) == 100
        assert len(dataset.data) == 100
        assert len(dataset.labels) == 100

    def test_getitem(self):
        dataset = Dataset(dataset_loader(dataset), dataset.labels)
        data_point, label = dataset.getitem(0)
        assert data_point.shape == (10,)
        assert label.shape == (10,)

class TestDatasetLoader:
    def test_init(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        assert dataset_loader.train_size == 0.8
        assert dataset_loader.val_size == 0.1
        assert dataset_loader.test_size == 0.1

    def test_get_dataloaders(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        train_dataloader, val_dataloader, test_dataloader = dataset_loader.get_dataloaders()
        assert len(train_dataloader) == 80
        assert len(val_dataloader) == 10
        assert len(test_dataloader) == 10

    def test_split_data(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        train_data, val_data, test_data = dataset_loader.split_data()
        assert len(train_data) == 80
        assert len(val_data) == 10
        assert len(test_data) == 10

class TestModel:
    def test_init(self):
        model = Model(10, 10, 1)
        assert model.fc1.in_features == 10
        assert model.fc1.out_features == 10
        assert model.fc2.in_features == 10
        assert model.fc2.out_features == 10
        assert model.fc3.in_features == 10
        assert model.fc3.out_features == 1

    def test_forward(self):
        model = Model(10, 10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        assert output.shape == (1, 1)

    def test_gradient_flow(self):
        model = Model(10, 10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        loss = mean_squared_error(input_data, output)
        loss.backward()

class TestLinearRegression:
    def test_init(self):
        model = LinearRegression(10, 1)
        assert model.weights.shape == (10, 1)
        assert model.bias.shape == (1,)

    def test_forward(self):
        model = LinearRegression(10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        assert output.shape == (1, 1)

    def test_gradient_flow(self):
        model = LinearRegression(10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        loss = mean_squared_error(input_data, output)
        loss.backward()

class TestTrainer:
    def test_init(self):
        trainer = Trainer(model, optimizer, dataset_loader(dataset), config)
        assert trainer.model == model
        assert trainer.optimizer == optimizer
        assert trainer.dataloader == dataset_loader(dataset)
        assert trainer.config == config

    def test_train(self):
        trainer = Trainer(model, optimizer, dataset_loader(dataset), config)
        trainer.train()

class TestModelTrainer:
    def test_init(self):
        trainer = ModelTrainer(model, optimizer, dataset_loader(dataset), config)
        assert trainer.model == model
        assert trainer.optimizer == optimizer
        assert trainer.dataloader == dataset_loader(dataset)
        assert trainer.config == config

    def test_train(self):
        trainer = ModelTrainer(model, optimizer, dataset_loader(dataset), config)
        trainer.train()

class TestModelEvaluator:
    def test_init(self):
        evaluator = ModelEvaluator(model, dataset_loader(dataset), config)
        assert evaluator.model == model
        assert evaluator.dataloader == dataset_loader(dataset)
        assert evaluator.config == config

    def test_evaluate(self):
        evaluator = ModelEvaluator(model, dataset_loader(dataset), config)
        for batch in evaluator.dataloader:
            input_data, labels = batch
            output = model(input_data)
            loss = mean_squared_error(labels, output)
            evaluator.evaluate()

    def test_calculate_metrics(self):
        evaluator = ModelEvaluator(model, dataset_loader(dataset), config)
        for batch in evaluator.dataloader:
            input_data, labels = batch
            output = model(input_data)
            loss = mean_squared_error(labels, output)
            metrics = evaluator.calculate_metrics(output, labels)
            assert metrics == {"loss_0": 0.0, "loss_1": 0.0, "loss_2": 0.0, "loss_3": 0.0}

class TestDataset:
    def test_len(self):
        dataset = Dataset(dataset_loader(dataset), dataset.labels)
        assert len(dataset) == 100
        assert len(dataset.data) == 100
        assert len(dataset.labels) == 100

    def test_getitem(self):
        dataset = Dataset(dataset_loader(dataset), dataset.labels)
        data_point, label = dataset.getitem(0)
        assert data_point.shape == (10,)
        assert label.shape == (10,)

class TestDatasetLoader:
    def test_init(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        assert dataset_loader.train_size == 0.8
        assert dataset_loader.val_size == 0.1
        assert dataset_loader.test_size == 0.1

    def test_get_dataloaders(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        train_dataloader, val_dataloader, test_dataloader = dataset_loader.get_dataloaders()
        assert len(train_dataloader) == 80
        assert len(val_dataloader) == 10
        assert len(test_dataloader) == 10

    def test_split_data(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        train_data, val_data, test_data = dataset_loader.split_data()
        assert len(train_data) == 80
        assert len(val_data) == 10
        assert len(test_data) == 10

class TestModel:
    def test_init(self):
        model = Model(10, 10, 1)
        assert model.fc1.in_features == 10
        assert model.fc1.out_features == 10
        assert model.fc2.in_features == 10
        assert model.fc2.out_features == 10
        assert model.fc3.in_features == 10
        assert model.fc3.out_features == 1

    def test_forward(self):
        model = Model(10, 10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        assert output.shape == (1, 1)

    def test_gradient_flow(self):
        model = Model(10, 10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        loss = mean_squared_error(input_data, output)
        loss.backward()

class TestLinearRegression:
    def test_init(self):
        model = LinearRegression(10, 1)
        assert model.weights.shape == (10, 1)
        assert model.bias.shape == (1,)

    def test_forward(self):
        model = LinearRegression(10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        assert output.shape == (1, 1)

    def test_gradient_flow(self):
        model = LinearRegression(10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        loss = mean_squared_error(input_data, output)
        loss.backward()

class TestTrainer:
    def test_init(self):
        trainer = Trainer(model, optimizer, dataset_loader(dataset), config)
        assert trainer.model == model
        assert trainer.optimizer == optimizer
        assert trainer.dataloader == dataset_loader(dataset)
        assert trainer.config == config

    def test_train(self):
        trainer = Trainer(model, optimizer, dataset_loader(dataset), config)
        trainer.train()

class TestModelTrainer:
    def test_init(self):
        trainer = ModelTrainer(model, optimizer, dataset_loader(dataset), config)
        assert trainer.model == model
        assert trainer.optimizer == optimizer
        assert trainer.dataloader == dataset_loader(dataset)
        assert trainer.config == config

    def test_train(self):
        trainer = ModelTrainer(model, optimizer, dataset_loader(dataset), config)
        trainer.train()

class TestModelEvaluator:
    def test_init(self):
        evaluator = ModelEvaluator(model, dataset_loader(dataset), config)
        assert evaluator.model == model
        assert evaluator.dataloader == dataset_loader(dataset)
        assert evaluator.config == config

    def test_evaluate(self):
        evaluator = ModelEvaluator(model, dataset_loader(dataset), config)
        for batch in evaluator.dataloader:
            input_data, labels = batch
            output = model(input_data)
            loss = mean_squared_error(labels, output)
            evaluator.evaluate()

    def test_calculate_metrics(self):
        evaluator = ModelEvaluator(model, dataset_loader(dataset), config)
        for batch in evaluator.dataloader:
            input_data, labels = batch
            output = model(input_data)
            loss = mean_squared_error(labels, output)
            metrics = evaluator.calculate_metrics(output, labels)
            assert metrics == {"loss_0": 0.0, "loss_1": 0.0, "loss_2": 0.0, "loss_3": 0.0}

class TestDataset:
    def test_len(self):
        dataset = Dataset(dataset_loader(dataset), dataset.labels)
        assert len(dataset) == 100
        assert len(dataset.data) == 100
        assert len(dataset.labels) == 100

    def test_getitem(self):
        dataset = Dataset(dataset_loader(dataset), dataset.labels)
        data_point, label = dataset.getitem(0)
        assert data_point.shape == (10,)
        assert label.shape == (10,)

class TestDatasetLoader:
    def test_init(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        assert dataset_loader.train_size == 0.8
        assert dataset_loader.val_size == 0.1
        assert dataset_loader.test_size == 0.1

    def test_get_dataloaders(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        train_dataloader, val_dataloader, test_dataloader = dataset_loader.get_dataloaders()
        assert len(train_dataloader) == 80
        assert len(val_dataloader) == 10
        assert len(test_dataloader) == 10

    def test_split_data(self):
        dataset_loader = DatasetLoader(dataset_loader(dataset), dataset.labels, train_size=0.8, val_size=0.1, test_size=0.1)
        train_data, val_data, test_data = dataset_loader.split_data()
        assert len(train_data) == 80
        assert len(val_data) == 10
        assert len(test_data) == 10

class TestModel:
    def test_init(self):
        model = Model(10, 10, 1)
        assert model.fc1.in_features == 10
        assert model.fc1.out_features == 10
        assert model.fc2.in_features == 10
        assert model.fc2.out_features == 10
        assert model.fc3.in_features == 10
        assert model.fc3.out_features == 1

    def test_forward(self):
        model = Model(10, 10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        assert output.shape == (1, 1)

    def test_gradient_flow(self):
        model = Model(10, 10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        loss = mean_squared_error(input_data, output)
        loss.backward()

class TestLinearRegression:
    def test_init(self):
        model = LinearRegression(10, 1)
        assert model.weights.shape == (10, 1)
        assert model.bias.shape == (1,)

    def test_forward(self):
        model = LinearRegression(10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        assert output.shape == (1, 1)

    def test_gradient_flow(self):
        model = LinearRegression(10, 1)
        input_data = torch.randn(1, 10)
        output = model(input_data)
        loss = mean_squared_error(input_data, output)
        loss.backward()

class TestTrainer:
    def test_init(self):
        trainer = Trainer(model, optimizer, dataset_loader(dataset), config)
        assert trainer.model == model