import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
import numpy as np
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Trainer:
    def __init__(self, model, optimizer, dataloader, config):
        self.model = model
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.config = config

    def train(self):
        logger.info("Training started")
        for epoch in range(self.config["epochs"]):
            logger.info(f"Epoch {epoch+1}")
            for batch in self.dataloader:
                # Forward pass
                inputs, labels = batch
                outputs = self.model(inputs)
                loss = self.calculate_loss(outputs, labels)

                # Backward pass
                self.optimizer.zero_grad()
                loss.backward()

                # Update model parameters
                self.model.step()

                # Log training metrics
                logger.info(f"Loss at epoch {epoch+1}: {loss.item():.4f}")

    def evaluate(self):
        logger.info("Evaluating model")
        with torch.no_grad():
            total_loss = 0
            for batch in self.dataloader:
                inputs, labels = batch
                outputs = self.model(inputs)
                loss = self.calculate_loss(outputs, labels)
                total_loss += loss.item()
            average_loss = total_loss / len(self.dataloader)
            logger.info(f"Average loss at epoch {self.config['epochs']}: {average_loss:.4f}")

    def save_checkpoint(self, state_dict):
        torch.save(state_dict, "model.pth")

    def calculate_loss(self, outputs, labels):
        # Implement your own loss function here
        # For example:
        # loss = (outputs - labels) ** 2
        # return loss.mean()
```

```python
class Model:
    def __init__(self, input_dim, hidden_dim, output_dim):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x
```

```python
class LinearRegression:
    def __init__(self, input_dim, output_dim):
        self.weights = nn.Parameter(torch.randn(input_dim, output_dim))
        self.bias = nn.Parameter(torch.zeros(output_dim))

    def forward(self, x):
        return torch.relu(self.weights * x + self.bias)
```

```python
class Dataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]
```

```python
class DataLoader:
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels
        self.batch_size = 32
        self.num_batches = len(data) // self.batch_size

    def __len__(self):
        return self.num_batches

    def __getitem__(self, idx):
        batch = self.data[idx * self.batch_size:(idx + 1) * self.batch_size]
        batch_labels = self.labels[idx * self.batch_size:(idx + 1) * self.batch_size]
        return batch, batch_labels
```

```python
class NeuralNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(NeuralNetwork, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x
```

```python
class LinearRegression:
    def __init__(self, input_dim, output_dim):
        self.weights = nn.Parameter(torch.randn(input_dim, output_dim))
        self.bias = nn.Parameter(torch.zeros(output_dim))

    def forward(self, x):
        return torch.relu(self.weights * x + self.bias)
```

```python
class Trainer:
    def __init__(self, model, optimizer, dataloader, config):
        self.model = model
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.config = config

    def train(self):
        for epoch in range(self.config["epochs"]):
            for batch in self.dataloader:
                inputs, labels = batch
                outputs = self.model(inputs)
                loss = self.calculate_loss(outputs, labels)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
            self.config["learning_rate"] *= 0.1
        self.save_checkpoint(self.model.state_dict())
```

```python
def train_model(model, optimizer, dataloader, config):
    trainer = Trainer(model, optimizer, dataloader, config)
    trainer.train()
```

```python
def evaluate_model(model, dataloader, config):
    trainer = Trainer(model, None, dataloader, config)
    trainer.evaluate()
```

```python
def save_model(model, optimizer, dataloader, config):
    trainer = Trainer(model, optimizer, dataloader, config)
    trainer.save_checkpoint(model.state_dict())
```

```python
def load_model(model, optimizer, dataloader, config):
    trainer = Trainer(model, optimizer, dataloader, config)
    return trainer.model.state_dict()
```

```python
def main():
    # Load data
    data = np.random.rand(100, 10)
    labels = np.random.rand(100)

    # Create dataset and dataloader
    dataset = Dataset(data, labels)
    dataloader = DataLoader(dataset, labels)

    # Create model
    model = NeuralNetwork(10, 10, 1)

    # Create optimizer and scheduler
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.1)

    # Train model
    train_model(model, optimizer, dataloader, {"epochs": 100, "batch_size": 32, "learning_rate": 0.01})

    # Evaluate model
    evaluate_model(model, dataloader, {"epochs": 100, "batch_size": 32, "learning_rate": 0.01})

    # Save model
    save_model(model, optimizer, dataloader, {"epochs": 100, "batch_size": 32, "learning_rate": 0.01})

if __name__ == "__main__":
    main()