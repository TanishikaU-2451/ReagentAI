import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
import numpy as np

class Dataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        data_point = self.data[idx]
        label = self.labels[idx]
        return data_point, label

class DatasetLoader:
    def __init__(self, data, labels, train_size=0.8, val_size=0.1, test_size=0.1):
        self.data = data
        self.labels = labels
        self.train_size = train_size
        self.val_size = val_size
        self.test_size = test_size

    def get_dataloaders(self):
        train_data, val_data, test_data = self.split_data()
        train_dataloader = DataLoader(train_data, batch_size=self.config["batch_size"], shuffle=True)
        val_dataloader = DataLoader(val_data, batch_size=self.config["batch_size"], shuffle=False)
        test_dataloader = DataLoader(test_data, batch_size=self.config["batch_size"], shuffle=False)
        return train_dataloader, val_dataloader, test_dataloader

    def split_data(self):
        train_data, val_data, test_data = train_test_split(self.data, self.labels, test_size=self.config["test_size"], random_state=42)
        return train_data, val_data, test_data

class Model(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(Model, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

class LinearRegression:
    def __init__(self, input_dim, output_dim):
        self.weights = nn.Parameter(torch.randn(input_dim, output_dim))
        self.bias = nn.Parameter(torch.zeros(output_dim))

    def forward(self, x):
        return torch.relu(self.fc1(x)) + self.fc2(x)

class Trainer:
    def __init__(self, model, optimizer, dataloader, config):
        self.model = model
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.config = config

    def train(self):
        logger.info("Training started")
        for epoch in range(self.config["epochs"]):
            logger.info(f"Epoch {epoch+1}")
            for batch in self.dataloader:
                # Forward pass
                inputs, labels = batch
                outputs = self.model(inputs)
                loss = self.calculate_loss(outputs, labels)

    def calculate_loss(self, outputs, labels):
        loss = mean_squared_error(labels, outputs)
        return loss

class ModelTrainer:
    def __init__(self, model, optimizer, dataloader, config):
        self.model = model
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.config = config

    def train(self):
        self.model.train()
        for batch in self.dataloader:
            # Forward pass
            inputs, labels = batch
            outputs = self.model(inputs)
            loss = self.calculate_loss(outputs, labels)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

    def calculate_loss(self, outputs, labels):
        loss = mean_squared_error(labels, outputs)
        return loss

class ModelEvaluator:
    def __init__(self, model, dataloader, config):
        self.model = model
        self.dataloader = dataloader
        self.config = config

    def evaluate(self):
        logger.info("Evaluating model")
        for batch in self.dataloader:
            # Forward pass
            inputs, labels = batch
            outputs = self.model(inputs)
            loss = mean_squared_error(labels, outputs)
            logger.info(f"Loss: {loss}")

    def calculate_metrics(self, outputs, labels):
        metrics = {}
        for i in range(len(outputs)):
            metrics[f"loss_{i+1}"] = mean_squared_error(labels[i], outputs[i])
        return metrics