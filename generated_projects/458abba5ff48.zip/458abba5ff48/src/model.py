import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from src.attention import Attention
from src.embeddings import Embeddings
from src.model import Model
from src.utils import model_summary

class Model(nn.Module):
    def __init__(self, config: dict):
        super(Model, self).__init__()
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )
        self.decision_tree = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )
        self.logistic_regression = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )
        self.optimizer = optim.Adam(self.parameters(), lr=config['learning_rate'])
        self.loss_fn = nn.MSELoss()
        self.model_summary = model_summary

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        attention_output = self.attention(x)
        embeddings_output = self.embeddings(x)
        neural_network_output = self.neural_network(embeddings_output)
        decision_tree_output = self.decision_tree(neural_network_output)
        logistic_regression_output = self.logistic_regression(decision_tree_output)
        return logistic_regression_output

    def train(self, x: torch.Tensor, y: torch.Tensor, batch_size: int, epochs: int) -> None:
        for epoch in range(epochs):
            for i, (x_batch, y_batch) in enumerate(zip(x, y)):
                self.optimizer.zero_grad()
                output = self(x_batch, y_batch)
                loss = self.loss_fn(output, y_batch)
                loss.backward()
                self.optimizer.step()
            self.model_summary('Epoch {}: Loss = {:.4f}'.format(epoch+1, loss.item()))

    def evaluate(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return self(x, y)

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        return self(x)