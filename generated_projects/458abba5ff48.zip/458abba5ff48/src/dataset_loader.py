import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from src.attention import Attention
from src.embeddings import Embeddings
from src.model import Model
from src.utils import model_summary

class Model(nn.Module):
    def __init__(self, config: dict):
        super(Model, self).__init__()
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )
        self.decision_tree = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the model.
        """
        return self.attention(x) + self.embeddings(x) + self.neural_network(x)

class Dataset(Dataset):
    def __init__(self, data: list, labels: list, config: dict):
        self.data = data
        self.labels = labels
        self.config = config

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        x = self.data[index]
        y = self.labels[index]
        return x, y

class DataLoader(Dataset):
    def __init__(self, data: list, labels: list, config: dict):
        self.data = data
        self.labels = labels
        self.config = config

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        x = self.data[index]
        y = self.labels[index]
        return x, y

def get_dataloaders(data: list, labels: list, config: dict, batch_size: int, train_split: float, val_split: float):
    train_data = data[:int(len(data) * train_split)]
    val_data = data[int(len(data) * train_split):int(len(data) * (train_split + val_split))]
    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_data, batch_size=batch_size, shuffle=False)
    return train_loader, val_loader

def train(model: Model, optimizer: optim.Adam, loss_fn: nn.CrossEntropyLoss, config: dict, train_loader: DataLoader, val_loader: DataLoader):
    model.train()
    for epoch in range(config['epochs']):
        for batch in train_loader:
            x, y = batch
            x, y = x.to('cuda'), y.to('cuda')
            optimizer.zero_grad()
            output = model(x)
            loss = loss_fn(output, y)
            loss.backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            total_loss = 0
            correct = 0
            for batch in val_loader:
                x, y = batch
                x, y = x.to('cuda'), y.to('cuda')
                output = model(x)
                loss = loss_fn(output, y)
                total_loss += loss.item()
                _, predicted = torch.max(output, 1)
                correct += (predicted == y).sum().item()
            accuracy = correct / len(y)
            print(f'Epoch {epoch+1}, Val Loss: {total_loss / len(val_loader)}')
            print(f'Epoch {epoch+1}, Val Acc: {accuracy:.4f}')

def main():
    config = {
        'learning_rate': 0.01,
        'batch_size': 32,
        'epochs': 100,
        'optimizer': 'Adam'
    }
    dataset = Dataset(data, labels, config)
    train_loader, val_loader = get_dataloaders(dataset.data, dataset.labels, config, config['batch_size'], config['train_split'], config['val_split'])
    model = Model(config)
    optimizer = optim.Adam(model.parameters(), lr=config['learning_rate'])
    loss_fn = nn.CrossEntropyLoss()
    train(model, optimizer, loss_fn, config, train_loader, val_loader)

if __name__ == '__main__':
    main()