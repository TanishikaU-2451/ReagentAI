import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from src.attention import Attention
from src.embeddings import Embeddings
from src.model import Model
from src.utils import model_summary
from torch.cuda.amp import autocast

class Trainer:
    def __init__(self, model: Model, optimizer: optim.Adam, dataloader: DataLoader, config: dict):
        self.model = model
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.config = config

    def train(self):
        for epoch in range(self.config['epochs']):
            for batch in self.dataloader:
                x, y = batch
                x = x.to('cuda' if torch.cuda.is_available() else 'cpu')
                y = y.to('cuda' if torch.cuda.is_available() else 'cpu')

                # Zero the gradients
                self.optimizer.zero_grad()

                # Forward pass
                y_pred = self.model(x)
                loss = self.model.loss(y_pred, y)

                # Backward pass
                loss.backward()

                # Update model parameters
                self.optimizer.step()

                # Log training metrics
                model_summary(self.model, x, y, y_pred, loss)

            # Log training metrics per epoch
            print(f'Epoch {epoch+1}, Loss: {loss.item()}')

    def evaluate(self):
        for batch in self.dataloader:
            x, y = batch
            x = x.to('cuda' if torch.cuda.is_available() else 'cpu')
            y = y.to('cuda' if torch.cuda.is_available() else 'cpu')

            # Forward pass
            y_pred = self.model(x)
            loss = self.model.loss(y_pred, y)

            # Log training metrics
            model_summary(self.model, x, y, y_pred, loss)

    def save_checkpoint(self, model, optimizer, dataloader, config):
        torch.save({
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'dataloader': dataloader.dataset,
            'config': config
        }, 'checkpoint.pth')