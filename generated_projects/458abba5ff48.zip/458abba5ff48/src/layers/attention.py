import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from src.attention import Attention
from src.embeddings import Embeddings
from src.model import Model
from src.utils import model_summary

class Model(nn.Module):
    """
    Multiple Linear Regression model.
    """
    def __init__(self, config: dict):
        super(Model, self).__init__()
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )
        self.decision_tree = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )
        self.optimizer = optim.Adam(self.parameters(), lr=config["learning_rate"])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the model.
        """
        x = self.attention(x)
        x = self.embeddings(x)
        x = self.neural_network(x)
        x = self.decision_tree(x)
        return x

class Encoder(nn.Module):
    """
    Encoder layer of the model.
    """
    def __init__(self, config: dict):
        super(Encoder, self).__init__()
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the encoder layer.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the encoder layer.
        """
        x = self.attention(x)
        x = self.embeddings(x)
        x = self.neural_network(x)
        return x

class Decoder(nn.Module):
    """
    Decoder layer of the model.
    """
    def __init__(self, config: dict):
        super(Decoder, self).__init__()
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the decoder layer.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the decoder layer.
        """
        x = self.attention(x)
        x = self.embeddings(x)
        x = self.neural_network(x)
        return x

class Model(nn.Module):
    """
    Multiple Linear Regression model.
    """
    def __init__(self, config: dict):
        super(Model, self).__init__()
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.encoder = Encoder(config)
        self.decoder = Decoder(config)
        self.optimizer = optim.Adam(self.parameters(), lr=config["learning_rate"])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the model.
        """
        x = self.attention(x)
        x = self.encoder(x)
        x = self.decoder(x)
        return x

class Dataset(Dataset):
    def __init__(self, x: torch.Tensor, y: torch.Tensor):
        self.x = x
        self.y = y

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return {"x": self.x[idx], "y": self.y[idx]}

class DataLoader(DataLoader):
    def __init__(self, dataset: Dataset, batch_size: int):
        super(DataLoader, self).__init__(dataset, batch_size=batch_size)

class ModelTrainer:
    def __init__(self, model: Model, config: dict):
        self.model = model
        self.config = config

    def train(self, train_dataset: Dataset, val_dataset: Dataset):
        """
        Train the model.

        Args:
            train_dataset (Dataset): Training dataset.
            val_dataset (Dataset): Validation dataset.
        """
        train_loader = DataLoader(train_dataset, batch_size=self.config["batch_size"])
        val_loader = DataLoader(val_dataset, batch_size=self.config["batch_size"])

        for epoch in range(self.config["epochs"]):
            for x, y in train_loader:
                self.model.train()
                self.optimizer.zero_grad()
                y_pred = self.model(x)
                loss = torch.nn.functional.mse_loss(y_pred, y)
                loss.backward()
                self.optimizer.step()
            print(f"Epoch {epoch+1}, Loss: {loss.item()}")

        with torch.no_grad():
            for x, y in val_loader:
                y_pred = self.model(x)
                loss = torch.nn.functional.mse_loss(y_pred, y)
                loss.backward()
                self.optimizer.step()
            print(f"Epoch {epoch+1}, Loss: {loss.item()}")

    def evaluate(self, test_dataset: Dataset):
        """
        Evaluate the model.

        Args:
            test_dataset (Dataset): Test dataset.
        """
        test_loader = DataLoader(test_dataset, batch_size=self.config["batch_size"])

        for x, y in test_loader:
            self.model.eval()
            with torch.no_grad():
                y_pred = self.model(x)
                loss = torch.nn.functional.mse_loss(y_pred, y)
            print(f"Test Loss: {loss.item()}")

# Example usage
if __name__ == "__main__":
    config = {
        "learning_rate": 0.01,
        "batch_size": 32,
        "epochs": 100,
        "optimizer": "Adam"
    }

    model = Model(config)
    trainer = ModelTrainer(model, config)

    train_dataset = Dataset(torch.randn(100, 6), torch.randn(100, 6))
    val_dataset = Dataset(torch.randn(10, 6), torch.randn(10, 6))
    trainer.train(train_dataset, val_dataset)

    test_dataset = Dataset(torch.randn(10, 6), torch.randn(10, 6))
    trainer.evaluate(test_dataset)