import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from src.attention import Attention
from src.embeddings import Embeddings
from src.model import Model
from src.utils import model_summary

class Model(nn.Module):
    """
    Multiple Linear Regression model.
    """
    def __init__(self, config: dict):
        super(Model, self).__init__()
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )
        self.decision_tree = nn.Sequential(
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 6)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the model.
        """
        x = self.attention(x)
        x = self.embeddings(x)
        x = self.neural_network(x)
        x = self.decision_tree(x)
        return x

class NeuralNetwork(nn.Module):
    """
    Neural Network layer of the model.
    """
    def __init__(self, config: dict):
        super(NeuralNetwork, self).__init__()
        self.linear1 = nn.Linear(6, 128)
        self.relu1 = nn.ReLU()
        self.linear2 = nn.Linear(128, 128)
        self.relu2 = nn.ReLU()
        self.linear3 = nn.Linear(128, 128)
        self.relu3 = nn.ReLU()
        self.linear4 = nn.Linear(128, 6)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the neural network layer.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the neural network layer.
        """
        x = self.relu1(self.linear1(x))
        x = self.relu2(self.linear2(x))
        x = self.relu3(self.linear3(x))
        x = self.relu4(self.linear4(x))
        return x

class DecisionTree(nn.Module):
    """
    Decision Tree layer of the model.
    """
    def __init__(self, config: dict):
        super(DecisionTree, self).__init__()
        self.linear1 = nn.Linear(6, 128)
        self.relu1 = nn.ReLU()
        self.linear2 = nn.Linear(128, 128)
        self.relu2 = nn.ReLU()
        self.linear3 = nn.Linear(128, 128)
        self.relu3 = nn.ReLU()
        self.linear4 = nn.Linear(128, 6)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the decision tree layer.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the decision tree layer.
        """
        x = self.relu1(self.linear1(x))
        x = self.relu2(self.linear2(x))
        x = self.relu3(self.linear3(x))
        x = self.relu4(self.linear4(x))
        return x

class LogisticRegression(nn.Module):
    """
    Logistic Regression layer of the model.
    """
    def __init__(self, config: dict):
        super(LogisticRegression, self).__init__()
        self.linear1 = nn.Linear(6, 128)
        self.relu1 = nn.ReLU()
        self.linear2 = nn.Linear(128, 128)
        self.relu2 = nn.ReLU()
        self.linear3 = nn.Linear(128, 128)
        self.relu3 = nn.ReLU()
        self.linear4 = nn.Linear(128, 6)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the logistic regression layer.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the logistic regression layer.
        """
        x = self.relu1(self.linear1(x))
        x = self.relu2(self.linear2(x))
        x = self.relu3(self.linear3(x))
        x = self.relu4(self.linear4(x))
        return x

class Decoder(nn.Module):
    """
    Decoder layer of the model.
    """
    def __init__(self, config: dict):
        super(Decoder, self).__init__()
        self.neural_network = nn.Sequential(
            NeuralNetwork(config),
            DecisionTree(config),
            LogisticRegression(config)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the decoder layer.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the decoder layer.
        """
        return self.neural_network(x)

class Encoder(nn.Module):
    """
    Encoder layer of the model.
    """
    def __init__(self, config: dict):
        super(Encoder, self).__init__()
        self.attention = Attention(config)
        self.embeddings = Embeddings(config)
        self.neural_network = nn.Sequential(
            NeuralNetwork(config),
            DecisionTree(config),
            LogisticRegression(config)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the encoder layer.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the encoder layer.
        """
        x = self.attention(x)
        x = self.embeddings(x)
        x = self.neural_network(x)
        return x

class Model(nn.Module):
    """
    Multiple Linear Regression model.
    """
    def __init__(self, config: dict):
        super(Model, self).__init__()
        self.encoder = Encoder(config)
        self.decoder = Decoder(config)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the model.
        """
        return self.encoder(x), self.decoder(x)

class Dataset(Dataset):
    """
    Dataset class for training data.
    """
    def __init__(self, config: dict):
        self.data = []

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index]

class DataLoader(Dataset):
    """
    DataLoader class for training data.
    """
    def __init__(self, config: dict):
        self.data = []
        self.index = 0

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index]

def main():
    config = {
        "learning_rate": 0.01,
        "batch_size": 32,
        "epochs": 100,
        "optimizer": "Adam"
    }

    model = Model(config)
    dataset = Dataset(config)
    data_loader = DataLoader(config)

    for epoch in range(config["epochs"]):
        for batch in data_loader:
            x, y = batch
            x = x.to("cuda")
            y = y.to("cuda")

            optimizer = optim.Adam(model.parameters(), lr=config["learning_rate"])
            loss = model(x, y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        model.eval()
        with torch.no_grad():
            predictions = []
            for batch in data_loader:
                x, y = batch
                x = x.to("cuda")
                y = y.to("cuda")

                predictions.append(model(x, y).cpu().numpy())

    model.eval()
    predictions = np.array(predictions)
    predictions = np.mean(predictions, axis=0)
    print(predictions)

if __name__ == "__main__":
    main()