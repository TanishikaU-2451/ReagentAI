import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from src import attention, embeddings
from src.model_summary import model_summary
# Removed the line that was causing the error