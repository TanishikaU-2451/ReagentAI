import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from src import attention, embeddings
from src.model_summary import model_summary

class Model(nn.Module):
    """
    A multiple linear regression model with attention and embeddings.
    """
    def __init__(self, config: dict):
        super(Model, self).__init__()
        self.attention = attention.Attention(config)
        self.embeddings = embeddings.Embeddings(config)
        self.linear = nn.Linear(config['num_features'], config['num_classes'])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the model.
        """
        x = self.attention(x)
        x = self.embeddings(x)
        x = self.linear(x)
        return x

    def model_summary(self):
        """
        Summary of the model.

        Returns:
        None
        """
        model_summary(model=self, config=self.config)

class SurveyRegression:
    """
    A multiple linear regression model with attention and embeddings.

    Attributes:
        config (dict): Hyperparameters of the model.
    """
    def __init__(self, config: dict):
        self.config = config
        self.model = Model(config)

    def train(self):
        """
        Train the model.

        Returns:
        None
        """
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(device)

        optimizer = optim.Adam(self.model.parameters(), lr=self.config['learning_rate'])
        scheduler = optim.Adam(self.model.parameters(), lr=self.config['learning_rate'], lr_schedule=self.config['optimizer'])

        for epoch in range(self.config['epochs']):
            for batch in DataLoader(SurveyRegressionDataset(self.config), batch_size=self.config['batch_size']):
                inputs, labels = batch
                inputs, labels = inputs.to(device), labels.to(device)

                optimizer.zero_grad()

                outputs = self.model(inputs)
                loss = torch.nn.CrossEntropyLoss()(outputs, labels)

                loss.backward()
                optimizer.step()

                scheduler.step()

            print(f'Epoch {epoch+1}, Loss: {loss.item()}')

class SurveyRegressionDataset(Dataset):
    """
    A dataset class for the survey regression model.

    Attributes:
        dataset (list): List of input-output pairs.
        device (torch.device): Device to move data to.
    """
    def __init__(self, config: dict):
        self.dataset = []
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        inputs, labels = self.dataset[idx]
        inputs, labels = inputs.to(self.device), labels.to(self.device)

        return inputs, labels

    def add_data(self, inputs, labels):
        self.dataset.append((inputs, labels))