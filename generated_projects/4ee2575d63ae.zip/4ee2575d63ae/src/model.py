import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from src import attention, embeddings
from src import layers
from src  (no files corrected)