import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, Any
from dataclasses import dataclass
from torch.utils.data import Dataset, DataLoader
from src.utils import model_summary

@dataclass
class ModelConfig:
    learning_rate: float = 0.01
    batch_size: int = 32
    epochs: int = 100
    optimizer: str = "Adam"

class Model(nn.Module):
    def __init__(self, config: ModelConfig):
        super(Model, self).__init__()
        self.config = config
        self.linear_regression = nn.Linear(config.batch_size, config.epochs)
        self.attention = nn.Linear(config.batch_size, config.epochs)
        self.embeddings = nn.Linear(config.batch_size, config.epochs)
        self.linear_regression.weight.data.fill_(0)
        self.linear_regression.bias.data.fill_(0)
        self.attention.weight.data.fill_(0)
        self.attention.bias.data.fill_(0)
        self.embeddings.weight.data.fill_(0)
        self.embeddings.bias.data.fill_(0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.exp(self.linear_regression(x) + self.attention(x) + self.embeddings(x))

class LinearRegression(nn.Module):
    def __init__(self, config: ModelConfig):
        super(LinearRegression, self).__init__()
        self.linear_regression = nn.Linear(config.batch_size, config.epochs)
        self.attention = nn.Linear(config.batch_size, config.epochs)
        self.embeddings = nn.Linear(config.batch_size, config.epochs)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.exp(self.linear_regression(x) + self.attention(x) + self.embeddings(x))

class Attention(nn.Module):
    def __init__(self, config: ModelConfig):
        super(Attention, self).__init__()
        self.attention = nn.Linear(config.batch_size, config.epochs)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.exp(self.attention(x))

class Embeddings(nn.Module):
    def __init__(self, config: ModelConfig):
        super(Embeddings, self).__init__()
        self.embeddings = nn.Linear(config.batch_size, config.epochs)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.exp(self.embeddings(x))

class Dataset(Dataset):
    def __init__(self, x: torch.Tensor, y: torch.Tensor):
        self.x = x
        self.y = y

    def __len__(self):
        return len(self.x)

    def __getitem__(self, index):
        return self.x[index], self.y[index]

class ModelTrainer:
    def __init__(self, model: nn.Module, config: ModelConfig):
        self.model = model
        self.config = config

    def train(self, dataset: Dataset, epochs: int):
        optimizer = optim.Adam(self.model.parameters(), lr=self.config.learning_rate)
        for epoch in range(epochs):
            for x, y in dataset:
                optimizer.zero_grad()
                output = self.model(x)
                loss = torch.nn.functional.mse_loss(output, y)
                loss.backward()
                optimizer.step()
            model_summary(self.model, epoch)

    def evaluate(self, dataset: Dataset):
        optimizer = optim.Adam(self.model.parameters(), lr=self.config.learning_rate)
        for x, y in dataset:
            optimizer.zero_grad()
            output = self.model(x)
            loss = torch.nn.functional.mse_loss(output, y)
            loss.backward()
            optimizer.step()
        return torch.exp(self.model(x) + self.model(x).mean() + self.model(x).mean() + self.model(x).mean())

def main():
    model_config = ModelConfig()
    model = Model(model_config)
    dataset = Dataset(torch.randn(100, 3), torch.randn(100, 3))
    trainer = ModelTrainer(model, model_config)
    trainer.train(dataset, 100)
    evaluation = trainer.evaluate(dataset)
    print(evaluation)

if __name__ == "__main__":
    main()