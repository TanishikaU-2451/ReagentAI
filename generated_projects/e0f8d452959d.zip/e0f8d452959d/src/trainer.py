import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, Any
from dataclasses import dataclass
from torch.utils.data import Dataset, DataLoader
from src.utils import model_summary

@dataclass
class ModelConfig:
    learning_rate: float = 0.01
    batch_size: int = 32
    epochs: int = 100
    optimizer: str = "Adam"

class Model(nn.Module):
    def __init__(self, config: ModelConfig):
        super(Model, self).__init__()
        self.config = config
        self.linear_regression = nn.Linear(config.batch_size, config.epochs)
        self.attention = nn.Linear(config.batch_size, config.epochs)
        self.embeddings = nn.Linear(config.batch_size, config.epochs)
        self.linear_regression.weight.data.fill_(0)
        self.linear_regression.bias.data.fill_(0)
        self.attention.weight.data.fill_(0)
        self.attention.bias.data.fill_(0)
        self.embeddings.weight.data.fill_(0)
        self.embeddings.bias.data.fill_(0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.exp(self.linear_regression(x) + self.attention(x) + self.embeddings(x))

class Trainer:
    def __init__(self, model: nn.Module, optimizer: optim.Optimizer, dataloader: DataLoader, config: ModelConfig):
        self.model = model
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)

    def train(self):
        for epoch in range(self.config.epochs):
            for x, y in self.dataloader:
                x = x.to(self.device)
                y = y.to(self.device)
                self.optimizer.zero_grad()
                output = self.model(x)
                loss = torch.nn.functional.mse_loss(output, y)
                loss.backward()
                self.optimizer.step()
                model_summary(self.model, epoch)

    def evaluate(self):
        with torch.no_grad():
            total_loss = 0
            for x, y in self.dataloader:
                x = x.to(self.device)
                y = y.to(self.device)
                output = self.model(x)
                loss = torch.nn.functional.mse_loss(output, y)
                total_loss += loss.item()
            return total_loss / len(self.dataloader)

    def save_checkpoint(self, filename: str):
        torch.save(self.model.state_dict(), filename)
        torch.save(self.optimizer.state_dict(), filename + "_optimizer")
        torch.save(self.dataloader.state_dict(), filename + "_dataloader")

def main():
    model_config = ModelConfig()
    model = Model(model_config)
    trainer = Trainer(model, optim.Adam(model.parameters(), lr=model_config.learning_rate), DataLoader(dataset, batch_size=model_config.batch_size), model_config)
    trainer.train()
    trainer.evaluate()
    trainer.save_checkpoint("model")

if __name__ == "__main__":
    main()