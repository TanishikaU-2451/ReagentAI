import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, Any
from dataclasses import dataclass
from torch.utils.data import Dataset, DataLoader
from src.utils import model_summary

@dataclass
class ModelConfig:
    learning_rate: float = 0.01
    batch_size: int = 32
    epochs: int = 100
    optimizer: str = "Adam"

class Model(nn.Module):
    def __init__(self, config: ModelConfig):
        super(Model, self).__init__()
        self.config = config
        self.linear_regression = nn.Linear(config.batch_size, config.epochs)
        self.attention = nn.Linear(config.batch_size, config.epochs)
        self.embeddings = nn.Linear(config.batch_size, config.epochs)
        self.linear_regression.weight.data.fill_(0)
        self.linear_regression.bias.data.fill_(0)
        self.attention.weight.data.fill_(0)
        self.attention.bias.data.fill_(0)
        self.embeddings.weight.data.fill_(0)
        self.embeddings.bias.data.fill_(0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.linear_regression(x)
        x = self.attention(x)
        x = self.embeddings(x)
        return x

    def model_summary(self) -> None:
        print(model_summary(self))

def train_model(config: ModelConfig, model: nn.Module, train_dataset: Dataset, val_dataset: Dataset, device: torch.device):
    model.to(device)
    optimizer = optim.Adam(model.parameters(), lr=config.learning_rate)
    train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.batch_size, shuffle=False)
    for epoch in range(config.epochs):
        model.train()
        total_loss = 0
        for batch in train_loader:
            inputs, labels = batch
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = nn.CrossEntropyLoss()(outputs, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f'Epoch {epoch+1}, Loss: {total_loss / len(train_loader)}')
        model.eval()
        with torch.no_grad():
            val_loss = 0
            correct = 0
            for batch in val_loader:
                inputs, labels = batch
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                loss = nn.CrossEntropyLoss()(outputs, labels)
                val_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                correct += (predicted == labels).sum().item()
            accuracy = correct / len(val_dataset)
            print(f'Epoch {epoch+1}, Val Loss: {val_loss / len(val_loader)}, Val Acc: {accuracy:.4f}')

def main():
    config = ModelConfig()
    model = Model(config)
    train_dataset = MyDataset()
    val_dataset = MyDataset()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    train_model(config, model, train_dataset, val_dataset, device)

if __name__ == '__main__':
    main()