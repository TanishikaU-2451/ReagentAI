import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from typing import Tuple, List
from sklearn.model_selection import train_test_split
import numpy as np

class DatasetLoader(Dataset):
    def __init__(self, data: List[Tuple[float, float, float]], labels: List[float]):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx: int) -> Tuple[float, float, float]:
        return self.data[idx]

def get_dataloaders(data: List[Tuple[float, float, float]], labels: List[float], train_size: float = 0.8, val_size: float = 0.1, test_size: float = 0.1) -> Tuple[DataLoader, DataLoader, DataLoader]:
    train_data, val_data, test_data = train_test_split(data, labels, test_size=test_size, random_state=42)
    train_labels, val_labels, test_labels = train_test_split(labels, train_size=val_size, random_state=42)
    train_data = torch.from_numpy(np.array(train_data)).float()
    val_data = torch.from_numpy(np.array(val_data)).float()
    test_data = torch.from_numpy(np.array(test_data)).float()
    train_labels = torch.from_numpy(np.array(train_labels)).float()
    val_labels = torch.from_numpy(np.array(val_labels)).float()
    test_labels = torch.from_numpy(np.array(test_labels)).float()
    return DataLoader(train_data, batch_size=32, shuffle=True), DataLoader(val_data, batch_size=32, shuffle=True), DataLoader(test_data, batch_size=32, shuffle=False)

def get_model(input_dim: int, output_dim: int) -> nn.Module:
    model = nn.Sequential(
        nn.Linear(input_dim, 10),
        nn.ReLU(),
        nn.Linear(10, 10),
        nn.ReLU(),
        nn.Linear(10, output_dim)
    )
    return model

def train_model(model: nn.Module, optimizer: optim.Adam, loss_fn: nn.MSELoss, train_loader: DataLoader, val_loader: DataLoader, epochs: int, learning_rate: float):
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for batch in train_loader:
            inputs, labels = batch
            inputs, labels = inputs.to('cuda'), labels.to('cuda')
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = loss_fn(outputs, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f'Epoch {epoch+1}, Loss: {total_loss / len(train_loader)}')

def evaluate_model(model: nn.Module, val_loader: DataLoader, val_loss_fn: nn.MSELoss):
    model.eval()
    total_loss = 0
    with torch.no_grad():
        for batch in val_loader:
            inputs, labels = batch
            inputs, labels = inputs.to('cuda'), labels.to('cuda')
            outputs = model(inputs)
            loss = val_loss_fn(outputs, labels)
            total_loss += loss.item()
    print(f'Validation Loss: {total_loss / len(val_loader)}')

def main():
    data = np.random.rand(100, 3)
    labels = np.random.rand(100)
    model = get_model(input_dim=3, output_dim=1)
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    loss_fn = nn.MSELoss()
    train_loader, val_loader, test_loader = get_dataloaders(data, labels)
    train_model(model, optimizer, loss_fn, train_loader, val_loader, epochs=100, learning_rate=learning_rate)
    evaluate_model(model, val_loader, loss_fn)

if __name__ == '__main__':
    main()