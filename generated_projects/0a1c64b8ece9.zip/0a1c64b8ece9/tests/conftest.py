import pytest
import torch
from src.model import Model
from src.trainer import Model as TrainerModel
from src.dataset import MockDataset
from src.utils import get_device

@pytest.fixture
def config():
    """Sample config dict matching the project's config.yaml structure."""
    return {
        "num_heads": 8,
        "dropout": 0.1,
        "d_model": 512,
        "num_embeddings": 1000,
        "embedding_dim": 128,
        "learning_rate": 1e-4,
        "batch_size": 32,
        "epochs": 10,
        "optimizer": "Adam",
        "other": {}
    }

@pytest.fixture
def input_tensor():
    """A small random input tensor for model forward-pass testing."""
    return torch.randn(1, 100, 128)

@pytest.fixture
def dataset():
    """A mock dataset with a few synthetic samples."""
    return MockDataset()

@pytest.fixture
def device():
    """A device fixture (cpu for CI, cuda if available)."""
    return get_device()

@pytest.fixture
def model():
    """A sample model instance."""
    return Model(config)