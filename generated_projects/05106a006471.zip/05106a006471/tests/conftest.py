import pytest
from conftest import (
    ConfigDict,
    SampleConfig,
    SampleInputTensor,
    SampleMockDataset,
    DeviceFixture,
)

@pytest.fixture
def sample_config():
    """Sample config dict matching the project's config.yaml structure."""
    return SampleConfig(
        learning_rate="0.01",
        batch_size="32",
        epochs="100",
        optimizer="Adam",
        other={"lr_decay": 0.5},
    )

@pytest.fixture
def sample_input_tensor():
    """A small random input tensor for model forward-pass testing."""
    return SampleInputTensor(
        shape=(10, 10), dtype=torch.float32, device="cpu"
    )

@pytest.fixture
def sample_mock_dataset():
    """A mock dataset with a few synthetic samples."""
    return SampleMockDataset(
        shape=(10, 10), dtype=torch.float32, device="cpu"
    )

@pytest.fixture
def device():
    """Device fixture (cpu for CI, cuda if available)."""
    return DeviceFixture(device="cpu")