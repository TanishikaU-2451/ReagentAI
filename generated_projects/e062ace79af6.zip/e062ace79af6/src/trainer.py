import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.attention = nn.MultiHeadAttention(64, 64)
        self.embeddings = nn.Embedding(1000, 64)
        selfRegression = nn.Linear(64, 1)

    def forward(self, x):
        x = self.embeddings(x)
        attention_output = self.attention(x, x)
        output = selfRegression(attention_output)
        return output

class Dataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]

class Trainer:
    def __init__(self, model, optimizer, dataloader, config):
        self.model = model
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.config = config

    def train(self):
        self.model.train()
        total_loss = 0
        for batch_idx, (data, labels) in enumerate(self.dataloader):
            data, labels = data.to('cuda' if torch.cuda.is_available() else 'cpu'), labels.to('cuda' if torch.cuda.is_available() else 'cpu')
            optimizer.zero_grad()
            output = self.model(data)
            loss = nn.MSELoss()(output, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f'Training Loss: {total_loss / len(self.dataloader)}')

    def evaluate(self):
        self.model.eval()
        total_loss = 0
        with torch.no_grad():
            for data, labels in self.dataloader:
                data, labels = data.to('cuda' if torch.cuda.is_available() else 'cpu'), labels.to('cuda' if torch.cuda.is_available() else 'cpu')
                output = self.model(data)
                loss = nn.MSELoss()(output, labels)
                total_loss += loss.item()
        print(f'Evaluation Loss: {total_loss / len(self.dataloader)}')

    def save_checkpoint(self, state_dict, optimizer, scheduler, epoch):
        torch.save({
            'state_dict': state_dict,
            'optimizer': optimizer.state_dict(),
            'scheduler': scheduler.state_dict(),
            'epoch': epoch
        }, 'checkpoint.pth')

    def load_checkpoint(self, checkpoint_path):
        checkpoint = torch.load(checkpoint_path)
        self.model.load_state_dict(checkpoint['state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        scheduler.load_state_dict(checkpoint['scheduler'])
        self.optimizer.step()
        self.scheduler.step()
        self.optimizer.zero_grad()
        return checkpoint['epoch']

def main():
    # Load data
    data = pd.read_csv('data.csv')
    labels = pd.read_csv('labels.csv')

    # Scale data
    scaler = StandardScaler()
    data[['x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8', 'x9', 'x10', 'x11', 'x12', 'x13', 'x14', 'x15', 'x16', 'x17', 'x18', 'x19', 'x20', 'x21', 'x22', 'x23', 'x24', 'x25', 'x26', 'x27', 'x28', 'x29', 'x30', 'x31', 'x32', 'x33', 'x34', 'x35', 'x36', 'x37', 'x38', 'x39', 'x40', 'x41', 'x42', 'x43', 'x44', 'x45', 'x46', 'x47', 'x48', 'x49', 'x50', 'x51', 'x52', 'x53', 'x54', 'x55', 'x56', 'x57', 'x58', 'x59', 'x60', 'x61', 'x62', 'x63', 'x64', 'x65', 'x66', 'x67', 'x68', 'x69', 'x70', 'x71', 'x72', 'x73', 'x74', 'x75', 'x76', 'x77', 'x78', 'x79', 'x80', 'x81', 'x82', 'x83', 'x84', 'x85', 'x86', 'x87', 'x88', 'x89', 'x90', 'x91', 'x92', 'x93', 'x94', 'x95', 'x96', 'x97', 'x98', 'x99', 'x100'] = data[['x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8', 'x9', 'x10', 'x11', 'x12', 'x13', 'x14', 'x15', 'x16', 'x17', 'x18', 'x19', 'x20', 'x21', 'x22', 'x23', 'x24', 'x25', 'x26', 'x27', 'x28', 'x29', 'x30', 'x31', 'x32', 'x33', 'x34', 'x35', 'x36', 'x37', 'x38', 'x39', 'x40', 'x41', 'x42', 'x43', 'x44', 'x45', 'x46', 'x47', 'x48', 'x49', 'x50', 'x51', 'x52', 'x53', 'x54', 'x55', 'x56', 'x57', 'x58', 'x59', 'x60', 'x61', 'x62', 'x63', 'x64', 'x65', 'x66', 'x67', 'x68', 'x69', 'x70', 'x71', 'x72', 'x73', 'x74', 'x75', 'x76', 'x77', 'x78', 'x79', 'x80', 'x81', 'x82', 'x83', 'x84', 'x85', 'x86', 'x87', 'x88', 'x89', 'x90', 'x91', 'x92', 'x93', 'x94', 'x95', 'x96', 'x97', 'x98', 'x99', 'x100']

    # Create dataset and data loader
    dataset = Dataset(data, labels)
    dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

    # Create model, optimizer, and scheduler
    model = Model()
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)

    # Train model
    trainer = Trainer(model, optimizer, dataloader, config)
    trainer.train()

    # Evaluate model
    trainer.evaluate()

    # Save checkpoint
    checkpoint_path = 'checkpoint.pth'
    trainer.save_checkpoint(trainer.state_dict(), optimizer, scheduler, trainer.load_checkpoint(checkpoint_path))

    # Load checkpoint
    checkpoint_path = 'checkpoint.pth'
    trainer.load_checkpoint(checkpoint_path)

    # Test model
    trainer.evaluate()

if __name__ == '__main__':
    main()