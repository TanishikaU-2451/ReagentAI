import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.attention = nn.MultiHeadAttention(64, 64)
        self.embeddings = nn.Embedding(1000, 64)
        selfRegression = nn.Linear(64, 1)

    def forward(self, x):
        x = self.embeddings(x)
        attention_output = self.attention(x, x)
        output = selfRegression(attention_output)
        return output

class Dataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        data_point = self.data[idx]
        label = self.labels[idx]
        return data_point, label

class NeuralNetwork(nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()
        self.model = Model()

    def forward(self, x):
        output = self.model(x)
        return output

class Regression:
    def __init__(self, model):
        self.model = model

    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model(X)

class Training:
    def __init__(self, model, optimizer, loss_fn, device):
        self.model = model
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.device = device

    def train(self, X, y):
        self.model.to(self.device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.01)
        self.loss_fn = nn.MSELoss()
        self.model.fit(X, y, epochs=100)

    def evaluate(self, X, y):
        self.model.to(self.device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.01)
        self.loss_fn = nn.MSELoss()
        self.model.fit(X, y, epochs=100)
        return self.model.predict(X)

class Main:
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def prepare_data(self):
        self.data = pd.DataFrame(self.data)
        self.labels = pd.Series(self.labels)
        self.data['x1'] = np.random.rand(len(self.data))
        self.data['x2'] = np.random.rand(len(self.data))
        self.data['x3'] = np.random.rand(len(self.data))
        self.labels = np.random.rand(len(self.labels))

    def prepare_dataset(self):
        self.dataset = Dataset(self.data, self.labels)

    def train_model(self, model, optimizer, loss_fn, device):
        train_loader = DataLoader(self.dataset, batch_size=32, shuffle=True)
        training = Training(model, optimizer, loss_fn, device)
        training.train(train_loader)

    def evaluate_model(self, model, device):
        model.to(device)
        model.eval()
        with torch.no_grad():
            predictions = model(self.dataset.data)
            loss = self.loss_fn(predictions, self.dataset.labels)
            accuracy = (predictions == self.dataset.labels).sum() / len(self.dataset.labels)
            return accuracy

    def run(self):
        self.prepare_data()
        self.prepare_dataset()
        self.train_model(self.model, self.optimizer, self.loss_fn, self.device)
        accuracy = self.evaluate_model(self.model, self.device)
        return accuracy

if __name__ == "__main__":
    data = pd.DataFrame({
        'x1': np.random.rand(100),
        'x2': np.random.rand(100),
        'x3': np.random.rand(100),
        'x4': np.random.rand(100),
        'x5': np.random.rand(100),
        'x6': np.random.rand(100),
        'x7': np.random.rand(100),
        'x8': np.random.rand(100),
        'x9': np.random.rand(100),
        'x10': np.random.rand(100),
        'x11': np.random.rand(100),
        'x12': np.random.rand(100),
        'x13': np.random.rand(100),
        'x14': np.random.rand(100),
        'x15': np.random.rand(100),
        'x16': np.random.rand(100),
        'x17': np.random.rand(100),
        'x18': np.random.rand(100),
        'x19': np.random.rand(100),
        'x20': np.random.rand(100),
        'x21': np.random.rand(100),
        'x22': np.random.rand(100),
        'x23': np.random.rand(100),
        'x24': np.random.rand(100),
        'x25': np.random.rand(100),
        'x26': np.random.rand(100),
        'x27': np.random.rand(100),
        'x28': np.random.rand(100),
        'x29': np.random.rand(100),
        'x30': np.random.rand(100),
        'x31': np.random.rand(100),
        'x32': np.random.rand(100),
        'x33': np.random.rand(100),
        'x34': np.random.rand(100),
        'x35': np.random.rand(100),
        'x36': np.random.rand(100),
        'x37': np.random.rand(100),
        'x38': np.random.rand(100),
        'x39': np.random.rand(100),
        'x40': np.random.rand(100),
        'x41': np.random.rand(100),
        'x42': np.random.rand(100),
        'x43': np.random.rand(100),
        'x44': np.random.rand(100),
        'x45': np.random.rand(100),
        'x46': np.random.rand(100),
        'x47': np.random.rand(100),
        'x48': np.random.rand(100),
        'x49': np.random.rand(100),
        'x50': np.random.rand(100),
        'x51': np.random.rand(100),
        'x52': np.random.rand(100),
        'x53': np.random.rand(100),
        'x54': np.random.rand(100),
        'x55': np.random.rand(100),
        'x56': np.random.rand(100),
        'x57': np.random.rand(100),
        'x58': np.random.rand(100),
        'x59': np.random.rand(100),
        'x60': np.random.rand(100),
        'x61': np.random.rand(100),
        'x62': np.random.rand(100),
        'x63': np.random.rand(100),
        'x64': np.random.rand(100),
        'x65': np.random.rand(100),
        'x66': np.random.rand(100),
        'x67': np.random.rand(100),
        'x68': np.random.rand(100),
        'x69': np.random.rand(100),
        'x70': np.random.rand(100),
        'x71': np.random.rand(100),
        'x72': np.random.rand(100),
        'x73': np.random.rand(100),
        'x74': np.random.rand(100),
        'x75': np.random.rand(100),
        'x76': np.random.rand(100),
        'x77': np.random.rand(100),
        'x78': np.random.rand(100),
        'x79': np.random.rand(100),
        'x80': np.random.rand(100),
        'x81': np.random.rand(100),
        'x82': np.random.rand(100),
        'x83': np.random.rand(100),
        'x84': np.random.rand(100),
        'x85': np.random.rand(100),
        'x86': np.random.rand(100),
        'x87': np.random.rand(100),
        'x88': np.random.rand(100),
        'x89': np.random.rand(100),
        'x90': np.random.rand(100),
        'x91': np.random.rand(100),
        'x92': np.random.rand(100),
        'x93': np.random.rand(100),
        'x94': np.random.rand(100),
        'x95': np.random.rand(100),
        'x96': np.random.rand(100),
        'x97': np.random.rand(100),
        'x98': np.random.rand(100),
        'x99': np.random.rand(100),
        'x100': np.random.rand(100),
    })
    labels = pd.Series(np.random.rand(100))

    main = Main(data, labels)

    accuracy = main.run()
    print(f"Accuracy: {accuracy:.2f}")