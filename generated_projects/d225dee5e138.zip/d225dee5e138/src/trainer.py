import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict
import logging
from trainer import Trainer
from model import Model
from embedding import Embedding
from bert import BERT
from optimizer import Optimizer
from scheduler import LearningRateScheduler
from utils import get_logger

logger = get_logger(__name__)

class PaperImplTrainer(Trainer):
    def __init__(self, model: Model, config: Dict, optimizer: Optimizer, dataloader: torch.utils.data.DataLoader, scheduler: LearningRateScheduler):
        super(PaperImplTrainer, self).__init__(model, config, optimizer, dataloader, scheduler)
        self.model = model
        self.config = config
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.scheduler = scheduler

    def train(self):
        self.model.train()
        for epoch in range(self.config['epochs']):
            logger.info(f'Epoch {epoch+1}')
            for batch_idx, (inputs, labels) in enumerate(self.dataloader):
                inputs, labels = inputs.to(self.config['device']), labels.to(self.config['device'])
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = F.cross_entropy(outputs, labels)
                loss.backward()
                self.optimizer.step()
                scheduler.step()
                logger.info(f'Batch {batch_idx+1}, Loss: {loss.item()}')
            self.scheduler.step()
            logger.info(f'Epoch {epoch+1}, Loss: {loss.item()}')

    def evaluate(self):
        self.model.eval()
        total_loss = 0
        correct = 0
        with torch.no_grad():
            for batch_idx, (inputs, labels) in enumerate(self.dataloader):
                inputs, labels = inputs.to(self.config['device']), labels.to(self.config['device'])
                outputs = self.model(inputs)
                loss = F.cross_entropy(outputs, labels)
                total_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                correct += (predicted == labels).sum().item()
        accuracy = correct / len(self.dataloader.dataset)
        logger.info(f'Epoch {self.config['epochs']}, Loss: {total_loss / len(self.dataloader)}, Accuracy: {accuracy:.4f}')

    def save_checkpoint(self, state_dict):
        torch.save(state_dict, 'model.pth')
        torch.save(self.optimizer.state_dict(), 'optimizer.pth')
        torch.save(self.dataloader.dataset, 'dataset.pth')
        torch.save(self.scheduler.state_dict(), 'scheduler.pth')