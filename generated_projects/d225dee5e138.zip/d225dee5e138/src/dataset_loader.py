import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict
import logging
from trainer import Trainer
from model import Model
from embedding import Embedding
from bert import BERT
from optimizer import Optimizer
from scheduler import LearningRateScheduler
from utils import get_logger

logger = get_logger(__name__)

class PaperImplTrainer(Trainer):
    def __init__(self, model: Model, config: Dict, optimizer: Optimizer, dataloader: torch.utils.data.DataLoader, scheduler: LearningRateScheduler):
        super(PaperImplTrainer, self).__init__(model, config, optimizer, dataloader, scheduler)
        self.model = model
        self.config = config
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.scheduler = scheduler

    def train(self):
        self.model.train()
        for epoch in range(self.config['epochs']):
            logger.info(f'Epoch {epoch+1}')
            for batch_idx, (inputs, labels) in enumerate(self.dataloader):
                inputs, labels = inputs.to(self.config['device']), labels.to(self.config['device'])

                # Zero the gradients
                self.optimizer.zero_grad()

                # Forward pass
                outputs = self.model(inputs)

                # Calculate the loss
                loss = F.cross_entropy(outputs, labels)

                # Backward pass
                loss.backward()

                # Update the model parameters
                self.optimizer.step()

                # Print the loss
                logger.info(f'Loss at epoch {epoch+1}, batch {batch_idx+1}: {loss.item()}')

            # Print the training statistics
            logger.info(f'Training statistics at epoch {epoch+1}:')
            logger.info(f'Epochs: {self.config["epochs"]}')
            logger.info(f'Batch sizes: {self.config["batch_size"]}')
            logger.info(f'Learning rates: {self.config["learning_rate"]}')
            logger.info(f'Optimizers: {self.optimizer}')
            logger.info(f'Dataloader sizes: {self.dataloader}')
            logger.info(f'Scheduler: {self.scheduler}')
            logger.info(f'Epochs: {self.config["epochs"]}')
            logger.info(f'Batch sizes: {self.config["batch_size"]}')
            logger.info(f'Learning rates: {self.config["learning_rate"]}')
            logger.info(f'Optimizers: {self.optimizer}')
            logger.info(f'Dataloader sizes: {self.dataloader}')
            logger.info(f'Scheduler: {self.scheduler}')
            logger.info(f'Epochs: {self.config["epochs"]}')
            logger.info(f'Batch sizes: {self.config["batch_size"]}')
            logger.info(f'Learning rates: {self.config["learning_rate"]}')
            logger.info(f'Optimizers: {self.optimizer}')
            logger.info(f'Dataloader sizes: {self.dataloader}')
            logger.info(f'Scheduler: {self.scheduler}')