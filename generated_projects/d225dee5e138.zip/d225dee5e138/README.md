import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict
import logging
from trainer import Trainer
from model import Model
from embedding import Embedding
from bert import BERT
from optimizer import Optimizer
from scheduler import LearningRateScheduler
from utils import get_logger

logger = get_logger(__name__)

class PaperImplTrainer(Trainer):
    def __init__(self, model: Model, config: Dict, optimizer: Optimizer, dataloader: torch.utils.data.DataLoader, scheduler: LearningRateScheduler):
        super(PaperImplTrainer, self).__init__(model, config, optimizer, dataloader, scheduler)
        self.model = model
        self.config = config
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.scheduler = scheduler

    def train(self):
        self.model.train()
        for epoch in range(self.config['epochs']):
            logger.info(f'Epoch {epoch+1}')
            for batch_idx, (inputs, labels) in enumerate(self.dataloader):
                inputs, labels = inputs.to(self.config['device']), labels.to(self.config['device'])

    def test(self):
        self.model.eval()
        test_loss = 0
        correct = 0
        with torch.no_grad():
            for batch_idx, (inputs, labels) in enumerate(self.dataloader):
                inputs, labels = inputs.to(self.config['device']), labels.to(self.config['device'])
                outputs = self.model(inputs)
                loss = F.cross_entropy(outputs, labels)
                test_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                correct += (predicted == labels).sum().item()
        accuracy = correct / len(self.dataloader)
        logger.info(f'Test Loss: {test_loss / len(self.dataloader)}')
        logger.info(f'Test Accuracy: {accuracy:.4f}')

    def save(self, filename: str):
        torch.save(self.model.state_dict(), filename)

    def load(self, filename: str):
        self.model.load_state_dict(torch.load(filename))

class Model(nn.Module):
    def __init__(self, config: Dict):
        super(Model, self).__init__()
        self.config = config
        self.bert = BERT(config)
        self.attention = Attention(config)
        self.embedding = Embedding(config)
        self.fc = nn.Linear(config['embedding_dim'], config['output_dim'])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.bert(x)
        x = self.attention(x)
        x = self.embedding(x)
        x = self.fc(x)
        return x

class BERT(nn.Module):
    def __init__(self, config: Dict):
        super(BERT, self).__init__()
        self.config = config
        self.transformer = Transformer(config)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.transformer(x)
        return x

class Attention(nn.Module):
    def __init__(self, config: Dict):
        super(Attention, self).__init__()
        self.config = config
        self.dropout = nn.Dropout(config['dropout_rate'])
        self.linear = nn.Linear(config['hidden_dim'], config['output_dim'])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        attention_weights = torch.matmul(x, x.T) / math.sqrt(config['hidden_dim'])
        attention_weights = F.softmax(attention_weights, dim=1)
        attention_weights = self.dropout(attention_weights)
        linear_output = torch.matmul(attention_weights, self.linear.weight)
        linear_output = F.relu(linear_output)
        linear_output = self.linear(linear_output)
        return linear_output

class Embedding(nn.Module):
    def __init__(self, config: Dict):
        super(Embedding, self).__init__()
        self.config = config
        self.embedding = nn.Embedding(config['embedding_dim'], config['embedding_dim'])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.embedding(x)

class Trainer:
    def __init__(self, model: Model, config: Dict, optimizer: Optimizer, dataloader: torch.utils.data.DataLoader, scheduler: LearningRateScheduler):
        self.model = model
        self.config = config
        self.optimizer = optimizer
        self.dataloader = dataloader
        self.scheduler = scheduler

    def train(self):
        self.model.train()
        for epoch in range(self.config['epochs']):
            logger.info(f'Epoch {epoch+1}')
            for batch_idx, (inputs, labels) in enumerate(self.dataloader):
                inputs, labels = inputs.to(self.config['device']), labels.to(self.config['device'])

class Optimizer:
    def __init__(self, learning_rate: float, batch_size: int, epochs: int):
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.epochs = epochs

class Scheduler:
    def __init__(self, learning_rate: float, epochs: int):
        self.learning_rate = learning_rate
        self.epochs = epochs

class Logger:
    def __init__(self, filename: str):
        self.filename = filename

    def info(self, message: str):
        with open(self.filename, 'a') as f:
            f.write(message + '\n')

    def error(self, message: str):
        with open(self.filename, 'a') as f:
            f.write(message + '\n')

    def debug(self, message: str):
        with open(self.filename, 'a') as f:
            f.write(message + '\n')

class Utils:
    def __init__(self):
        pass

    def get_logger(self, name: str):
        return Logger(f'{name}.log')

    def save(self, model: nn.Module, filename: str):
        torch.save(model.state_dict(), filename)

    def load(self, filename: str):
        model = torch.load(filename)
        return model

class EmbeddingUtil:
    def __init__(self):
        pass

    def get_embedding_dim(self, config: Dict):
        return config['embedding_dim']

    def get_embedding_dim_from_config(self, config: Dict):
        return config['embedding_dim']

    def get_embedding_dim_from_file(self, filename: str):
        with open(filename, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_config_file_to_config_file(self, config_file: str):
        with open(config_file, 'r') as f:
            return int(f.read())

    def get_embedding_dim_from_file_to_config