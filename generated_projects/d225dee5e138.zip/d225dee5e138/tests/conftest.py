import pytest
from conftest import (
    config,
    sample_input_tensor,
    mock_dataset,
    device,
)

@pytest.fixture
def config_dict():
    return {
        "learning_rate": 0.001,
        "batch_size": 32,
        "epochs": 10,
        "optimizer": "Adam",
        "other": {},
    }

@pytest.fixture
def sample_input_tensor():
    return torch.randn(1, 10, 10)

@pytest.fixture
def mock_dataset():
    class MockDataset(torch.utils.data.Dataset):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, idx):
            return self.data[idx]

        def __len__(self):
            return len(self.data)

    return MockDataset([sample_input_tensor])

@pytest.fixture
def device():
    return device