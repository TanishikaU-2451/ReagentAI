import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict
import math
import torch.nn.functional as F
from conftest import *

class TestModel:
    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_model_init(self, config):
        model = Model(config)
        assert isinstance(model, nn.Module)
        assert hasattr(model, "bert")
        assert hasattr(model, "attention")
        assert hasattr(model, "embedding")
        assert hasattr(model, "fc")

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        output = model(x)
        assert output.shape == (1, 10)

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_shape(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        output = model(x)
        assert output.shape == (1, 10)

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_type(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        output = model(x)
        assert isinstance(output, torch.Tensor)

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_type_shape(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        output = model(x)
        assert output.shape == (1, 10)

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_type_type(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        output = model(x)
        assert isinstance(output, torch.Tensor)

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_shape(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_shape_type(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type_shape(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type_type_shape(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type_shape_type(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type_shape_type_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type_shape_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type_shape_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type_shape_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_type_shape_grad_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_grad_shape(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_grad_shape_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_grad_shape_grad_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_grad_shape_grad_grad_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_grad_shape_grad_grad_grad_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_grad_shape_grad_grad_grad_grad_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_grad_shape_grad_grad_grad_grad_grad_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.attention, model.embedding, model.fc], retain_graph=True):
            pass

    @pytest.mark.parametrize("config", [{"embedding_dim": 128, "output_dim": 10}, {"embedding_dim": 256, "output_dim": 20}])
    def test_forward_pass_grad_grad_shape_grad_grad_grad_grad_grad_grad_grad_grad(self, config):
        model = Model(config)
        x = torch.randn(1, 10, 10, 10, 10, 10)
        with torch.no_grad():
            output = model(x)
        with torch.autograd.grad([output], [model.bert, model.att