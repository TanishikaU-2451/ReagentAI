import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from typing import Tuple
import numpy as np

class DatasetLoader(Dataset):
    def __init__(self, data: Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float]]):
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx: int) -> Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float]]:
        return self.data[idx]

def get_dataloaders(data: Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float]], 
                    train_size: float = 0.8, val_size: float = 0.1, test_size: float = 0.1) -> Tuple[DataLoader, DataLoader, DataLoader]:
    train_data, val_data, test_data = train_test_split(data, train_size, val_size, test_size)
    train_loader = DataLoader(train_data, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_data, batch_size=32, shuffle=False)
    test_loader = DataLoader(test_data, batch_size=32, shuffle=False)
    return train_loader, val_loader, test_loader

def pi(X: Tuple[float, float], y: Tuple[float, float]) -> float:
    """
    Calculate the value of π using the equation: π = × (X^T X)^-1 X^T y

    Args:
        X (Tuple[float, float]): The input data
        y (Tuple[float, float]): The target data

    Returns:
        float: The calculated value of π
    """
    return torch.dot(X, X.T) / torch.dot(y, y.T)

def train_model(X: Tuple[float, float], y: Tuple[float, float], 
                train_loader: DataLoader, val_loader: DataLoader, optimizer: optim.Adam, 
                learning_rate: float = 0.01, batch_size: int = 32, epochs: int = 100):
    """
    Train the model using gradient descent

    Args:
        X (Tuple[float, float]): The input data
        y (Tuple[float, float]): The target data
        train_loader (DataLoader): The training data loader
        val_loader (DataLoader): The validation data loader
        optimizer (optim.Adam): The optimizer
        learning_rate (float, optional): The learning rate. Defaults to 0.01.
        batch_size (int, optional): The batch size. Defaults to 32.
        epochs (int, optional): The number of epochs. Defaults to 100.
    """
    for epoch in range(epochs):
        for batch_idx, (data, target) in enumerate(train_loader):
            # Zero the gradients
            optimizer.zero_grad()

            # Forward pass
            output = pi(data, target)

            # Calculate the loss
            loss = torch.mean((output - target) ** 2)

            # Backward pass
            loss.backward()

            # Update the model parameters
            optimizer.step()

            # Print the loss
            print(f'Epoch {epoch+1}, Batch {batch_idx+1}, Loss: {loss.item()}')

def main():
    # Load the data
    data = np.random.rand(100, 2)

    # Create a dataset loader
    train_loader, val_loader, test_loader = get_dataloaders((data, data, data, data), train_size=0.8, val_size=0.1, test_size=0.1)

    # Create a model
    model = nn.Linear(2, 1)

    # Initialize the model, loss function, and optimizer
    model = nn.Linear(2, 1)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.01)

    # Train the model
    train_model(data, data, train_loader, val_loader, optimizer, learning_rate=0.01, batch_size=32, epochs=100)

if __name__ == '__main__':
    main()