import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from typing import Tuple

class DatasetLoader(Dataset):
    def __init__(self, data: Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float]]):
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx: int) -> Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float]]:
        return self.data[idx]

def get_dataloaders(data: Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float]], 
                    train_size: float = 0.8, val_size: float = 0.1, test_size: float = 0.1) -> Tuple[DataLoader, DataLoader, DataLoader]:
    train_data, val_data, test_data = train_test_split(data, train_size, val_size, test_size)
    train_loader = DataLoader(train_data, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_data, batch_size=32, shuffle=False)
    test_loader = DataLoader(test_data, batch_size=32, shuffle=False)
    return train_loader, val_loader, test_loader

def pi(X: Tuple[float, float], y: Tuple[float, float]) -> float:
    return torch.dot(X, X.T) / torch.dot(y, y.T)

def train_model(X: Tuple[float, float], y: Tuple[float, float], 
                train_loader: DataLoader, val_loader: DataLoader, optimizer: optim.Adam, 
                learning_rate: float = 0.01, epochs: int = 100) -> Tuple[nn.Linear, nn.Linear]:
    model = nn.Linear(2, 1)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    for epoch in range(epochs):
        for batch in train_loader:
            X, y = batch
            optimizer.zero_grad()
            y_pred = model(X)
            loss = criterion(y_pred, y)
            loss.backward()
            optimizer.step()
        print(f'Epoch {epoch+1}, Loss: {loss.item()}')

    return model, criterion

def evaluate_model(model: nn.Linear, criterion: nn.MSELoss, test_loader: DataLoader) -> float:
    with torch.no_grad():
        y_pred = model(test_loader.dataset[0])
        loss = criterion(y_pred, test_loader.dataset[1])
        return loss.item()

def main():
    # Load data
    data = ((0.1, 0.2), (0.3, 0.4), (0.5, 0.6), (0.7, 0.8))
    train_loader, val_loader, test_loader = get_dataloaders(data)

    # Define model and optimizer
    model, criterion = train_model(X=(0.1, 0.2), y=(0.3, 0.4), train_loader=train_loader, val_loader=val_loader, optimizer=optim.Adam, learning_rate=0.01)

    # Evaluate model
    print(f'Evaluating model on test data...')

    # Evaluate model on test data
    test_loss = evaluate_model(model, criterion, test_loader)

    print(f'Test loss: {test_loss}')

if __name__ == '__main__':
    main()