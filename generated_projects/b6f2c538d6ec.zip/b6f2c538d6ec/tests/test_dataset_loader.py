import pytest
import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import Adam
from torch.nn import Linear, Embedding, MultiHeadAttention, Dropout
from torch.nn.functional import softmax
from conftest import *

def test_dataset_loader():
    data = np.random.rand(10, 100)
    labels = np.random.randint(0, 2, 10)
    dataset = DatasetLoader(data, labels, transform=None)
    assert dataset.data.shape == (10, 100)
    assert dataset.labels.shape == (10,)
    with pytest.raises(ValueError):
        dataset = DatasetLoader(data, labels, transform=torch.zeros(10, 100))

def test_model():
    model = Model()
    assert isinstance(model, nn.Module)
    assert hasattr(model, 'attention')
    assert hasattr(model, 'embedding')
    assert hasattr(model, 'fc1')
    assert hasattr(model, 'fc2')
    assert hasattr(model, 'fc3')
    assert hasattr(model, 'fc4')
    assert hasattr(model, 'fc5')
    assert hasattr(model, 'fc6')
    assert hasattr(model, 'fc7')
    assert hasattr(model, 'fc8')
    assert hasattr(model, 'fc9')
    assert hasattr(model, 'fc10')
    assert hasattr(model, 'fc11')
    assert hasattr(model, 'fc12')
    assert hasattr(model, 'fc13')
    assert hasattr(model, 'fc14')
    assert hasattr(model, 'fc15')
    assert hasattr(model, 'fc16')
    assert hasattr(model, 'fc17')

def test_trainer():
    model = Model()
    optimizer = Adam(model.parameters(), lr=0.01)
    loss_fn = nn.CrossEntropyLoss()
    trainer = Trainer(model, optimizer, loss_fn, torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    assert isinstance(trainer, Trainer)
    assert isinstance(optimizer, Adam)
    assert isinstance(loss_fn, nn.CrossEntropyLoss)
    assert isinstance(trainer.model, Model)
    assert isinstance(trainer.optimizer, Adam)
    assert isinstance(trainer.loss_fn, nn.CrossEntropyLoss)
    assert isinstance(trainer.device, torch.device)
    assert trainer.train.__name__ == 'train'
    assert trainer.evaluate.__name__ == 'evaluate'

def test_model_forward_pass():
    model = Model()
    input_data = torch.randn(1, 100)
    output = model(input_data)
    assert output.shape == (1, 64)

def test_model_gradient_flow():
    model = Model()
    input_data = torch.randn(1, 100)
    output = model(input_data)
    loss = nn.CrossEntropyLoss()(output, torch.randn(1, 100))
    loss.backward()
    assert not torch.isnan(loss)

def test_trainer_single_step():
    model = Model()
    optimizer = Adam(model.parameters(), lr=0.01)
    loss_fn = nn.CrossEntropyLoss()
    trainer = Trainer(model, optimizer, loss_fn, torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    trainer.train(DataLoader([torch.randn(1, 100)], torch.randn(1, 100)), torch.randn(1, 100), 1)
    assert trainer.optimizer.step() is not None

def test_dataset_len():
    dataset = DatasetLoader([torch.randn(1, 100)], torch.randn(1, 100))
    assert len(dataset) == 1

def test_dataset_getitem():
    dataset = DatasetLoader([torch.randn(1, 100)], torch.randn(1, 100))
    data, labels = dataset[0]
    assert data.shape == (1, 100)
    assert labels.shape == (1,)