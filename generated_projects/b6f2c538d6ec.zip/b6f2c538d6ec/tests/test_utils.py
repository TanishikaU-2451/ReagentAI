import pytest
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import TensorDataset, DataLoader
from torch.optim import Adam
from torch.nn import Linear, Embedding, MultiHeadAttention, Dropout
from torch.nn.functional import softmax

@pytest.fixture
def model():
    return Model()

@pytest.fixture
def dataset_loader():
    data = pd.DataFrame({'input': np.random.rand(100, 100)})
    labels = pd.DataFrame({'input': np.random.rand(100, 100)})
    transform = None
    return DatasetLoader(data, labels, transform=transform)

@pytest.fixture
def train_data():
    return pd.DataFrame({'input': np.random.rand(100, 100)})

@pytest.fixture
def train_labels():
    return pd.DataFrame({'input': np.random.rand(100, 100)})

@pytest.fixture
def val_data():
    return pd.DataFrame({'input': np.random.rand(100, 100)})

@pytest.fixture
def val_labels():
    return pd.DataFrame({'input': np.random.rand(100, 100)})

def test_model(model):
    # Test forward pass with random input
    input_tensor = torch.randn(1, 100, 100)
    output = model(input_tensor)
    assert output.shape == (1, 100, 100)

    # Test output shape
    assert output.shape == (1, 100, 100)

    # Test gradient flow
    input_tensor = torch.randn(1, 100, 100)
    output = model(input_tensor)
    loss = torch.randn(1, 1)
    loss.backward()
    assert torch.isclose(output.grad, loss.grad)

def test_dataset_loader(dataset_loader):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_train_model(model, train_data, train_labels, val_data, val_labels):
    # Test that a single training step runs without error
    model.train()
    train_model(model, device, train_data, train_labels, optim.Adam(model.parameters(), lr=0.01), criterion, epochs=100)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_train_model(model, train_data, train_labels, val_data, val_labels):
    # Test that a single training step runs without error
    model.train()
    train_model(model, device, train_data, train_labels, optim.Adam(model.parameters(), lr=0.01), criterion, epochs=100)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_model(model, train_data, train_labels, val_data, val_labels):
    # Test that the model can be instantiated with default config
    model = Model()
    assert model.attention == nn.MultiHeadAttention(64, 64)
    assert model.embedding == nn.Embedding(1000, 64)
    assert model.fc1 == nn.Linear(64, 64)
    assert model.fc2 == nn.Linear(64, 64)
    assert model.fc3 == nn.Linear(64, 64)
    assert model.fc4 == nn.Linear(64, 64)
    assert model.fc5 == nn.Linear(64, 64)
    assert model.fc6 == nn.Linear(64, 64)
    assert model.fc7 == nn.Linear(64, 64)
    assert model.fc8 == nn.Linear(64, 64)
    assert model.fc9 == nn.Linear(64, 64)
    assert model.fc10 == nn.Linear(64, 64)
    assert model.fc11 == nn.Linear(64, 64)
    assert model.fc12 == nn.Linear(64, 64)
    assert model.fc13 == nn.Linear(64, 64)
    assert model.fc14 == nn.Linear(64, 64)
    assert model.fc15 == nn.Linear(64, 64)
    assert model.fc16 == nn.Linear(64, 64)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_train_model(model, train_data, train_labels, val_data, val_labels):
    # Test that a single training step runs without error
    model.train()
    train_model(model, device, train_data, train_labels, optim.Adam(model.parameters(), lr=0.01), criterion, epochs=100)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_model(model, train_data, train_labels, val_data, val_labels):
    # Test that the model can be instantiated with default config
    model = Model()
    assert model.attention == nn.MultiHeadAttention(64, 64)
    assert model.embedding == nn.Embedding(1000, 64)
    assert model.fc1 == nn.Linear(64, 64)
    assert model.fc2 == nn.Linear(64, 64)
    assert model.fc3 == nn.Linear(64, 64)
    assert model.fc4 == nn.Linear(64, 64)
    assert model.fc5 == nn.Linear(64, 64)
    assert model.fc6 == nn.Linear(64, 64)
    assert model.fc7 == nn.Linear(64, 64)
    assert model.fc8 == nn.Linear(64, 64)
    assert model.fc9 == nn.Linear(64, 64)
    assert model.fc10 == nn.Linear(64, 64)
    assert model.fc11 == nn.Linear(64, 64)
    assert model.fc12 == nn.Linear(64, 64)
    assert model.fc13 == nn.Linear(64, 64)
    assert model.fc14 == nn.Linear(64, 64)
    assert model.fc15 == nn.Linear(64, 64)
    assert model.fc16 == nn.Linear(64, 64)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_train_model(model, train_data, train_labels, val_data, val_labels):
    # Test that a single training step runs without error
    model.train()
    train_model(model, device, train_data, train_labels, optim.Adam(model.parameters(), lr=0.01), criterion, epochs=100)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_model(model, train_data, train_labels, val_data, val_labels):
    # Test that the model can be instantiated with default config
    model = Model()
    assert model.attention == nn.MultiHeadAttention(64, 64)
    assert model.embedding == nn.Embedding(1000, 64)
    assert model.fc1 == nn.Linear(64, 64)
    assert model.fc2 == nn.Linear(64, 64)
    assert model.fc3 == nn.Linear(64, 64)
    assert model.fc4 == nn.Linear(64, 64)
    assert model.fc5 == nn.Linear(64, 64)
    assert model.fc6 == nn.Linear(64, 64)
    assert model.fc7 == nn.Linear(64, 64)
    assert model.fc8 == nn.Linear(64, 64)
    assert model.fc9 == nn.Linear(64, 64)
    assert model.fc10 == nn.Linear(64, 64)
    assert model.fc11 == nn.Linear(64, 64)
    assert model.fc12 == nn.Linear(64, 64)
    assert model.fc13 == nn.Linear(64, 64)
    assert model.fc14 == nn.Linear(64, 64)
    assert model.fc15 == nn.Linear(64, 64)
    assert model.fc16 == nn.Linear(64, 64)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_train_model(model, train_data, train_labels, val_data, val_labels):
    # Test that a single training step runs without error
    model.train()
    train_model(model, device, train_data, train_labels, optim.Adam(model.parameters(), lr=0.01), criterion, epochs=100)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_model(model, train_data, train_labels, val_data, val_labels):
    # Test that the model can be instantiated with default config
    model = Model()
    assert model.attention == nn.MultiHeadAttention(64, 64)
    assert model.embedding == nn.Embedding(1000, 64)
    assert model.fc1 == nn.Linear(64, 64)
    assert model.fc2 == nn.Linear(64, 64)
    assert model.fc3 == nn.Linear(64, 64)
    assert model.fc4 == nn.Linear(64, 64)
    assert model.fc5 == nn.Linear(64, 64)
    assert model.fc6 == nn.Linear(64, 64)
    assert model.fc7 == nn.Linear(64, 64)
    assert model.fc8 == nn.Linear(64, 64)
    assert model.fc9 == nn.Linear(64, 64)
    assert model.fc10 == nn.Linear(64, 64)
    assert model.fc11 == nn.Linear(64, 64)
    assert model.fc12 == nn.Linear(64, 64)
    assert model.fc13 == nn.Linear(64, 64)
    assert model.fc14 == nn.Linear(64, 64)
    assert model.fc15 == nn.Linear(64, 64)
    assert model.fc16 == nn.Linear(64, 64)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_train_model(model, train_data, train_labels, val_data, val_labels):
    # Test that a single training step runs without error
    model.train()
    train_model(model, device, train_data, train_labels, optim.Adam(model.parameters(), lr=0.01), criterion, epochs=100)

def test_dataset_loader(dataset_loader, train_data, train_labels, val_data, val_labels):
    # Test __len__
    assert len(dataset_loader) == 1

    # Test __getitem__
    input_tensor, labels, transform = dataset_loader.__getitem__(0)
    assert input_tensor.shape == (1, 100, 100)
    assert labels.shape == (1, 100, 100)

def test_model(model, train_data, train_labels, val_data, val_labels):
    # Test that the model can be instantiated with default config
    model = Model()
    assert model.attention == nn.MultiHeadAttention(64, 64)
    assert model.embedding == nn.Embedding(1000, 64)
    assert model.fc1 == nn.Linear(64, 64)
    assert model.fc2 == nn.Linear(64, 64)
    assert model.fc3 == nn.Linear(64, 64)
    assert model.fc4 == nn.Linear(64, 64)
    assert model.fc5 == nn.Linear(64, 64)
    assert model.fc6 == nn.Linear(64, 64)
    assert model.fc7 == nn.Linear(64, 64)