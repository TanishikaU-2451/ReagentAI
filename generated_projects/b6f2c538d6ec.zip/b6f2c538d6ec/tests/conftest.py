import pytest
from conftest import Hyperparameters
from src.model import Model
from src.dataset_loader import DatasetLoader
from src.utils import torch_utils

@pytest.fixture
def config():
    """Sample config dict matching the project's config.yaml structure."""
    return {
        "learning_rate": "0.001",
        "batch_size": 32,
        "epochs": 10,
        "optimizer": "Adam",
        "other": {}
    }

@pytest.fixture
def input_tensor():
    """A sample random input tensor for model forward-pass testing."""
    return torch.randn(1, 100)

@pytest.fixture
def dataset():
    """A mock dataset with a few synthetic samples."""
    data = torch.randn(100, 100)
    labels = torch.randint(0, 2, (100,))
    return DatasetLoader(data, labels, transform=None)

@pytest.fixture
def device():
    """Device fixture (cpu for CI, cuda if available)."""
    if torch.cuda.is_available():
        device = "cuda"
    else:
        device = "cpu"
    return device

def test_model(config, input_tensor, dataset, device):
    model = Model()
    model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"])
    loss_fn = torch.nn.CrossEntropyLoss()
    model.train()
    for epoch in range(config["epochs"]):
        for batch_idx, (data, labels) in enumerate(dataset):
            data, labels = data.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(data)
            loss = loss_fn(outputs, labels)
            loss.backward()
            optimizer.step()
        print(f"Epoch {epoch+1}, Loss: {loss.item():.4f}")