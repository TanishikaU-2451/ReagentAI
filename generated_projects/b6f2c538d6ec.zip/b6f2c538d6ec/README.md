import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import TensorDataset, DataLoader
from torch.optim import Adam
from torch.nn import Linear, Embedding, MultiHeadAttention, Dropout
from torch.nn.functional import softmax

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.attention = nn.MultiHeadAttention(64, 64)
        self.embedding = nn.Embedding(1000, 64)
        self.fc1 = nn.Linear(64, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, 64)
        self.fc4 = nn.Linear(64, 64)
        self.fc5 = nn.Linear(64, 64)
        self.fc6 = nn.Linear(64, 64)
        self.fc7 = nn.Linear(64, 64)
        self.fc8 = nn.Linear(64, 64)
        self.fc9 = nn.Linear(64, 64)
        self.fc10 = nn.Linear(64, 64)
        self.fc11 = nn.Linear(64, 64)
        self.fc12 = nn.Linear(64, 64)
        self.fc13 = nn.Linear(64, 64)
        self.fc14 = nn.Linear(64, 64)
        self.fc15 = nn.Linear(64, 64)
        self.fc16 = nn.Linear(64, 64)
        self.fc17 = nn.Linear(64, 64)

    def forward(self, x, y):
        attention_output = self.attention(x, y)
        embedding_output = self.embedding(x)
        output = torch.cat((attention_output, embedding_output), dim=1)
        output = self.fc1(output)
        output = self.fc2(output)
        output = self.fc3(output)
        output = self.fc4(output)
        output = self.fc5(output)
        output = self.fc6(output)
        output = self.fc7(output)
        output = self.fc8(output)
        output = self.fc9(output)
        output = self.fc10(output)
        output = self.fc11(output)
        output = self.fc12(output)
        output = self.fc13(output)
        output = self.fc14(output)
        output = self.fc15(output)
        output = self.fc16(output)
        output = self.fc17(output)
        return output

class DatasetLoader(Dataset):
    def __init__(self, data, labels, transform=None):
        self.data = data
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]

class Trainer:
    def __init__(self, model, optimizer, loss_fn, device):
        self.model = model
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.device = device

    def train(self, data, labels):
        self.model.to(self.device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.01)
        self.loss_fn = nn.CrossEntropyLoss()
        self.model.train()
        for epoch in range(self.optimizer.param_groups[0]['lr'].as_scalar(100)):
            for x, y in data:
                x, y = x.to(self.device), y.to(self.device)
                self.optimizer.zero_grad()
                output = self.model(x, y)
                loss = self.loss_fn(output, y)
                loss.backward()
                self.optimizer.step()
            print(f'Epoch {epoch+1}, Loss: {loss.item()}')

    def evaluate(self, data, labels):
        self.model.to(self.device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.01)
        self.loss_fn = nn.CrossEntropyLoss()
        self.model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for x, y in data:
                x, y = x.to(self.device), y.to(self.device)
                output = self.model(x, y)
                _, predicted = torch.max(output, 1)
                correct += (predicted == y).sum().item()
                total += len(x)
        accuracy = correct / total
        print(f'Accuracy: {accuracy:.4f}')

def main():
    # Load data
    data = pd.read_csv('data.csv')
    labels = pd.read_csv('labels.csv')

    # Split data into training and testing sets
    train_data, test_data, train_labels, test_labels = train_test_split(data, labels, test_size=0.2, random_state=42)

    # Create dataset loaders
    train_dataset = DatasetLoader(train_data, train_labels, transform=None)
    test_dataset = DatasetLoader(test_data, test_labels, transform=None)

    # Create model and trainer
    model = Model()
    trainer = Trainer(model, optim.Adam(model.parameters(), lr=0.01), nn.CrossEntropyLoss(), device='cuda')

    # Train model
    trainer.train(train_dataset, train_labels)

    # Evaluate model
    trainer.evaluate(test_dataset, test_labels)

if __name__ == '__main__':
    main()