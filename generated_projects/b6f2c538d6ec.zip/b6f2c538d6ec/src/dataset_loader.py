import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import TensorDataset, DataLoader
from torch.optim import Adam
from torch.nn import Linear, Embedding, MultiHeadAttention, Dropout
from torch.nn.functional import softmax

class DatasetLoader(Dataset):
    def __init__(self, data, labels, transform=None):
        self.data = data
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        if self.transform is not None:
            data = self.transform(self.data[idx])
        else:
            data = self.data[idx]
        return data, self.labels[idx]

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.attention = nn.MultiHeadAttention(64, 64)
        self.embedding = nn.Embedding(1000, 64)
        self.fc1 = nn.Linear(64, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, 64)
        self.fc4 = nn.Linear(64, 64)
        self.fc5 = nn.Linear(64, 64)
        self.fc6 = nn.Linear(64, 64)
        self.fc7 = nn.Linear(64, 64)
        self.fc8 = nn.Linear(64, 64)
        self.fc9 = nn.Linear(64, 64)
        self.fc10 = nn.Linear(64, 64)
        self.fc11 = nn.Linear(64, 64)
        self.fc12 = nn.Linear(64, 64)
        self.fc13 = nn.Linear(64, 64)
        self.fc14 = nn.Linear(64, 64)
        self.fc15 = nn.Linear(64, 64)
        self.fc16 = nn.Linear(64, 64)
        self.fc17 = nn.Linear(64, 64)

    def forward(self, x):
        attention_output = self.attention(x, x)
        embedded_output = self.embedding(attention_output)
        output = torch.relu(self.fc1(embedded_output))
        output = torch.relu(self.fc2(output))
        output = torch.relu(self.fc3(output))
        output = torch.relu(self.fc4(output))
        output = torch.relu(self.fc5(output))
        output = torch.relu(self.fc6(output))
        output = torch.relu(self.fc7(output))
        output = torch.relu(self.fc8(output))
        output = torch.relu(self.fc9(output))
        output = torch.relu(self.fc10(output))
        output = torch.relu(self.fc11(output))
        output = torch.relu(self.fc12(output))
        output = torch.relu(self.fc13(output))
        output = torch.relu(self.fc14(output))
        output = torch.relu(self.fc15(output))
        output = torch.relu(self.fc16(output))
        output = torch.relu(self.fc17(output))
        return output

class Trainer:
    def __init__(self, model, optimizer, loss_fn, device):
        self.model = model
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.device = device

    def train(self, data_loader, labels, epochs):
        for epoch in range(epochs):
            running_loss = 0.0
            for i, (data, labels) in enumerate(data_loader):
                data, labels = data.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                output = self.model(data)
                loss = self.loss_fn(output, labels)
                loss.backward()
                self.optimizer.step()
                running_loss += loss.item()
            print(f'Epoch {epoch+1}, Loss: {running_loss / len(data_loader)}')

    def evaluate(self, data_loader, labels):
        correct = 0
        total = 0
        with torch.no_grad():
            for data, labels in data_loader:
                data, labels = data.to(self.device), labels.to(self.device)
                output = self.model(data)
                _, predicted = torch.max(output, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        accuracy = correct / total
        print(f'Accuracy: {accuracy:.4f}')

def main():
    # Load data
    data = pd.read_csv('data.csv')
    labels = pd.read_csv('labels.csv')

    # Split data into training and validation sets
    train_data, val_data, train_labels, val_labels = train_test_split(data, labels, test_size=0.2, random_state=42)

    # Create dataset loaders
    train_dataset = DatasetLoader(train_data, train_labels, transform=None)
    val_dataset = DatasetLoader(val_data, val_labels, transform=None)

    # Create model and optimizer
    model = Model()
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    loss_fn = nn.CrossEntropyLoss()

    # Create trainer
    trainer = Trainer(model, optimizer, loss_fn, torch.device('cuda' if torch.cuda.is_available() else 'cpu'))

    # Train model
    trainer.train(train_dataset, train_labels, epochs=100)

    # Evaluate model
    trainer.evaluate(val_dataset, val_labels)

if __name__ == '__main__':
    main()