import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import TensorDataset, DataLoader
from torch.optim import Adam
from torch.nn import Linear, Embedding, MultiHeadAttention, Dropout
from torch.nn.functional import softmax

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.attention = nn.MultiHeadAttention(64, 64)
        self.embedding = nn.Embedding(1000, 64)
        self.fc1 = nn.Linear(64, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, 64)
        self.fc4 = nn.Linear(64, 64)
        self.fc5 = nn.Linear(64, 64)
        self.fc6 = nn.Linear(64, 64)
        self.fc7 = nn.Linear(64, 64)
        self.fc8 = nn.Linear(64, 64)
        self.fc9 = nn.Linear(64, 64)
        self.fc10 = nn.Linear(64, 64)
        self.fc11 = nn.Linear(64, 64)
        self.fc12 = nn.Linear(64, 64)
        self.fc13 = nn.Linear(64, 64)
        self.fc14 = nn.Linear(64, 64)
        self.fc15 = nn.Linear(64, 64)
        self.fc16 = nn.Linear(64, 64)
        self.fc17 = nn.Linear(64, 64)

    def forward(self, x, y):
        attention_output = self.attention(x, y)
        embedded_output = self.embedding(x)
        output = torch.cat((attention_output, embedded_output), dim=1)
        output = self.fc1(output)
        output = self.fc2(output)
        output = self.fc3(output)
        output = self.fc4(output)
        output = self.fc5(output)
        output = self.fc6(output)
        output = self.fc7(output)
        output = self.fc8(output)
        output = self.fc9(output)
        output = self.fc10(output)
        output = self.fc11(output)
        output = self.fc12(output)
        output = self.fc13(output)
        output = self.fc14(output)
        output = self.fc15(output)
        output = self.fc16(output)
        output = self.fc17(output)
        return output

class DatasetLoader(Dataset):
    def __init__(self, data, labels, transform=None):
        self.data = data
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx], self.transform[idx]

def train_model(model, device, data, labels, optimizer, loss_fn, epochs):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    criterion = nn.CrossEntropyLoss()
    loss_fn = criterion
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for batch_idx, (data_batch, labels_batch, _) in enumerate(train_test_split(data, labels, test_size=0.2, random_state=42)):
            data_batch, labels_batch, _ = data_batch.to(device), labels_batch.to(device), transform_batch
            optimizer.zero_grad()
            output = model(data_batch, labels_batch)
            loss = loss_fn(output, labels_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f"Epoch {epoch+1}, Loss: {total_loss / len(data) * 100:.2f}%")

def main():
    # Load data
    data = pd.read_csv("data.csv")
    labels = pd.read_csv("labels.csv")

    # Split data into training and validation sets
    train_data, val_data, train_labels, val_labels = train_test_split(data, labels, test_size=0.2, random_state=42)

    # Create dataset loaders
    train_dataset = DatasetLoader(train_data, train_labels, transform=None)
    val_dataset = DatasetLoader(val_data, val_labels, transform=None)

    # Create data loaders
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)

    # Define model
    model = Model()

    # Define optimizer and loss function
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    criterion = nn.CrossEntropyLoss()

    # Train model
    train_model(model, device, train_loader, val_loader, optimizer, criterion, epochs=100)

if __name__ == "__main__":
    main()