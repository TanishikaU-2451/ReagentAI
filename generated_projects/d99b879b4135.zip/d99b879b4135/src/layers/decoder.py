import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, Any
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class ModelConfig:
    learning_rate: float
    batch_size: int
    epochs: int
    optimizer: str

@dataclass
class ModelConfigDict:
    config: ModelConfig

class NeuralNetwork(nn.Module):
    def __init__(self, config: ModelConfigDict):
        super(NeuralNetwork, self).__init__()
        self.config = config
        self.neural_network = nn.Sequential(
            nn.Linear(3, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, 3)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.neural_network(x)

class DecisionTree(nn.Module):
    def __init__(self, config: ModelConfigDict):
        super(DecisionTree, self).__init__()
        self.config = config
        self.tree = nn.Sequential(
            nn.Linear(3, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, 3)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.tree(x)

class RandomForest(nn.Module):
    def __init__(self, config: ModelConfigDict):
        super(RandomForest, self).__init__()
        self.config = config
        self.tree = nn.Sequential(
            nn.Linear(3, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, 3)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.tree(x)

class Model(nn.Module):
    def __init__(self, config: ModelConfigDict):
        super(Model, self).__init__()
        self.config = config
        self.neural_network = NeuralNetwork(config)
        self.decision_tree = DecisionTree(config)
        self.random_forest = RandomForest(config)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.neural_network(x) + self.decision_tree(x) + self.random_forest(x)

class TrainingStrategy:
    def __init__(self, config: ModelConfigDict):
        self.config = config
        self.optimizer = optim.Adam(self.config.config.optimizer, lr=self.config.config.learning_rate)

    def train(self, x: torch.Tensor, y: torch.Tensor):
        optimizer = optim.Adam(self.config.config.optimizer, lr=self.config.config.learning_rate)
        loss_fn = nn.MSELoss()
        for epoch in range(self.config.config.epochs):
            optimizer.zero_grad()
            outputs = self(x)
            loss = loss_fn(outputs, y)
            loss.backward()
            optimizer.step()
            print(f'Epoch {epoch+1}, Loss: {loss.item()}')

class ModelRunner:
    def __init__(self, config: ModelConfigDict):
        self.config = config
        self.model = Model(config)

    def train(self, x: torch.Tensor, y: torch.Tensor):
        training_strategy = TrainingStrategy(self.config)
        training_strategy.train(x, y)

    def evaluate(self, x: torch.Tensor, y: torch.Tensor):
        return self.model(x)

# Example usage
if __name__ == '__main__':
    model_config = ModelConfigDict({
        'learning_rate': 0.01,
        'batch_size': 32,
        'epochs': 100,
        'optimizer': 'Adam'
    })

    model = Model(model_config)
    model_runner = ModelRunner(model_config)

    x = torch.randn(100, 3)
    y = torch.randn(100, 3)

    model_runner.train(x, y)
    print(model_runner.evaluate(x, y))