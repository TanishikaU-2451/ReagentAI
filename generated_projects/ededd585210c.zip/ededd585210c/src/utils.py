import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from typing import Dict, List
from src.attention import Attention
from src.embeddings import Embeddings
from src.model import Model
from src.utils import ModelSummary

class PaperImpl(Model):
    """
    A PyTorch model for multiple linear regression.
    """

    def __init__(self, config: Dict):
        """
        Initializes the model.

        Args:
            config (Dict): Hyperparameters for the model.
        """
        super().__init__()
        self.config = config
        self.model = self._build_model()
        self.optimizer = optim.Adam(self.model.parameters(), lr=config["learning_rate"])
        self.model_summary = ModelSummary(self.model)

    def _build_model(self) -> nn.Module:
        """
        Builds the model.

        Returns:
            nn.Module: The trained model.
        """
        attention = Attention()
        embeddings = Embeddings()
        model = nn.Sequential(
            embeddings,
            nn.Linear(3, 10),
            nn.ReLU(),
            nn.Linear(10, 10),
            nn.ReLU(),
            nn.Linear(10, 1)

        return model

    def train(self, data_loader: DataLoader, epoch: int) -> None:
        """
        Trains the model.

        Args:
            data_loader (DataLoader): The data loader.
            epoch (int): The current epoch.
        """
        for batch in data_loader:
            x, y = batch
            y_pred = self.model(x)
            loss = self._loss(y_pred, y)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

    def _loss(self, y_pred: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Computes the loss.

        Args:
            y_pred (torch.Tensor): The predicted values.
            y (torch.Tensor): The actual values.

        Returns:
            torch.Tensor: The loss.
        """
        y = y.expand(-1, y_pred.shape[-1])
        return torch.mean((y - y_pred) ** 2)

    def evaluate(self, data_loader: DataLoader) -> None:
        """
        Evaluates the model.

        Args:
            data_loader (DataLoader): The data loader.
        """
        for batch in data_loader:
            x, y = batch
            y_pred = self.model(x)
            loss = self._loss(y_pred, y)
            print(f"Epoch {epoch+1}, Loss: {loss.item()}")

    def predict(self, data_loader: DataLoader) -> torch.Tensor:
        """
        Makes predictions.

        Args:
            data_loader (DataLoader): The data loader.

        Returns:
            torch.Tensor: The predicted values.
        """
        for batch in data_loader:
            x, y = batch
            y_pred = self.model(x)
            return y_pred

class ModelSummary(nn.Module):
    """
    A summary of the model.
    """
    def __init__(self, model: nn.Module):
        super().__init__()
        self.model = model

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Args:
            x (torch.Tensor): The input.

        Returns:
            torch.Tensor: The output.
        """
        return self.model(x)

class DatasetLoader:
    """
    A dataset loader.
    """
    def __init__(self, config: Dict):
        self.config = config
        self.data = self._load_data()

    def _load_data(self) -> List[Dict]:
        """
        Loads the data.

        Returns:
            List[Dict]: The data.
        """
        # Load the data here
        return [{"x": [1, 2, 3], "y": [4, 5, 6]}]

class Attention:
    """
    An attention module.
    """
    def __init__(self):
        pass

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Args:
            x (torch.Tensor): The input.

        Returns:
            torch.Tensor: The output.
        """
        return x

class Embeddings:
    """
    An embeddings module.
    """
    def __init__(self):
        pass

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Args:
            x (torch.Tensor): The input.

        Returns:
            torch.Tensor: The output.
        """
        return x

class Model:
    """
    A model.
    """
    def __init__(self):
        pass

    def _build_model(self) -> nn.Module:
        """
        Builds the model.

        Returns:
            nn.Module: The model.
        """
        return nn.Sequential(
            nn.Linear(3, 10),
            nn.ReLU(),
            nn.Linear(10, 10),
            nn.ReLU(),
            nn.Linear(10, 1)
        )